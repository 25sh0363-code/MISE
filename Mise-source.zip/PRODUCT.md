# MISE
<!-- impeccable:product-schema 1 -->

## Platform
adaptive

## Stack
User-specified React Native, Expo, TypeScript, Expo Router, NativeWind, Reanimated, Gesture Handler, Expo SQLite, Supabase, Zustand, TanStack Query, Zod, Notifications, Speech, Image Picker and Haptics. Native iOS and Android only.

## Users
Home cooks who want guided practice and a personal record of what they actually cooked.

## Product Purpose
Turn cooking into a personalized culinary adventure. First milestone: discover and save a cheeseburger, cook with recoverable timers, review the result, record a journal entry, and earn real practice XP, all offline.

## Operating Context
Hands occupied in a home kitchen, intermittent connectivity, backgrounded applications. One step at a time; large targets; spoken instructions; no continuous background listening.

## Capabilities and Constraints
SQLite is the local source of truth. Saved recipes, sessions and journals work without cloud credentials. Supabase is optional until configured. AI runs server-side, uses validated structured output, and never alters saved recipes without confirmation. Never fabricate cooking history or progress. Timing uses durable timestamps. Cloud secrets never enter the app.

## Brand Commitments
Warm editorial cooking adventure. Ivory #F8F5EF, cream #EFE8DA, forest #344E41, sage #A3B18A, terracotta #C87956, espresso #29251F, muted gold #D4A65A. Cozy progression, premium native navigation, food photography. Five tabs: Kitchen, Discover, Cookbook, Journey, Chef.

## Evidence on Hand
User supplied detailed product brief and five Burger Workshop recipe names. Complete recipes will be authored as starter content. No user history, achievements, photos or cloud credentials supplied.

## Product Principles
- Earn progress through completed, recorded practice.
- Protect local data before synchronization.
- Cooking stays usable when the internet disappears.
- Make the next cooking action obvious.

## Accessibility & Inclusion
Safe areas, scalable text, 48-point controls, screen-reader labels, reduced motion, system light/dark appearance. User-supplied allergies must inform AI context; recommendations are not allergy certification.

## Open Decisions
No additional user preferences assumed beyond the supplied brief. Initial first-milestone priority follows the explicit request.
