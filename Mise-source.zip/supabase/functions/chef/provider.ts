// A small server-only boundary. Providers return the same validated domain shape.
// Add adapters here without changing the mobile app or transmitting provider keys.
export type ChatMessage = { role: 'system' | 'user' | 'assistant'; content: string };
export async function generateStructuredReply(messages: ChatMessage[], schema: Record<string, unknown>): Promise<unknown> {
  const base = Deno.env.get('AI_BASE_URL');
  const key = Deno.env.get('AI_API_KEY');
  const model = Deno.env.get('AI_MODEL');
  const adapter = Deno.env.get('AI_ADAPTER') ?? 'openai-compatible';
  if (!base || !key || !model) throw new Error('AI_NOT_CONFIGURED');
  if (new URL(base).protocol !== 'https:') throw new Error('AI_CONFIG_INVALID');
  const endpoint = base.replace(/\/+$/, '');
  const signal = AbortSignal.timeout(45000);
  if (adapter === 'openai-compatible') {
    const response = await fetch(`${endpoint}/chat/completions`, {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model, messages, max_tokens: 6000, response_format: { type: 'json_schema', json_schema: { name: 'mise_chef_reply', strict: true, schema } } }),
    });
    if (!response.ok) throw new Error('AI_UPSTREAM_FAILED');
    const result = await response.json();
    const content = result.choices?.[0]?.message?.content;
    if (typeof content !== 'string') throw new Error('AI_INVALID_RESPONSE');
    return JSON.parse(content);
  }
  if (adapter === 'anthropic') {
    const response = await fetch(`${endpoint}/messages`, {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model, max_tokens: 6000, system: messages.filter(m => m.role === 'system').map(m => m.content).join('\n'), messages: messages.filter(m => m.role !== 'system'), tools: [{ name: 'mise_chef_reply', description: 'Return structured cooking guidance or a complete recipe draft.', input_schema: schema }], tool_choice: { type: 'tool', name: 'mise_chef_reply' } }),
    });
    if (!response.ok) throw new Error('AI_UPSTREAM_FAILED');
    const result = await response.json();
    const tool = result.content?.find((part: { type: string; name?: string }) => part.type === 'tool_use' && part.name === 'mise_chef_reply');
    if (!tool?.input) throw new Error('AI_INVALID_RESPONSE');
    return tool.input;
  }
  throw new Error('AI_ADAPTER_UNSUPPORTED');
}
