import { z } from 'npm:zod@3.25.76';

export const draftSchema = z.object({
  name: z.string().min(1).max(150), description: z.string().min(1).max(2000),
  cuisine: z.string().min(1).max(80), category: z.string().min(1).max(80),
  ingredients: z.array(z.object({ id: z.string().min(1).max(80), name: z.string().min(1).max(200), quantity: z.number().positive().max(100000), unit: z.string().max(50) })).min(1).max(60),
  steps: z.array(z.object({ id: z.string().min(1).max(80), title: z.string().min(1).max(150), instruction: z.string().min(1).max(4000), durationSeconds: z.number().int().positive().max(86400).nullable(), ingredients: z.array(z.string()).max(60) })).min(1).max(40),
  equipment: z.array(z.string().max(100)).min(1).max(30), prepMinutes: z.number().int().nonnegative().max(2880), cookMinutes: z.number().int().nonnegative().max(2880),
  difficulty: z.number().int().min(1).max(5), servings: z.number().int().min(1).max(100), skills: z.array(z.string().max(100)).max(15), notes: z.string().max(4000),
}).superRefine((recipe, ctx) => {
  if (new Set(recipe.ingredients.map(i => i.id)).size !== recipe.ingredients.length) ctx.addIssue({ code: 'custom', message: 'Ingredient IDs must be unique' });
  if (new Set(recipe.steps.map(s => s.id)).size !== recipe.steps.length) ctx.addIssue({ code: 'custom', message: 'Step IDs must be unique' });
});
export const providerReplySchema = z.object({ kind: z.enum(['guidance', 'recipe']), message: z.string().min(1).max(12000), recipe: draftSchema.nullable(), safetyNote: z.string().max(2000).nullable() });
const localContextSchema = z.object({ preferences: z.object({ experience: z.string().max(100), cuisines: z.array(z.string().max(100)).max(40), dietary: z.array(z.string().max(100)).max(40), allergies: z.string().max(4000), equipment: z.array(z.string().max(100)).max(50), goals: z.array(z.string().max(200)).max(40), onboarded: z.boolean(), theme: z.enum(['system', 'light', 'dark']) }).optional(), recentPractice: z.array(z.record(z.unknown())).max(10).optional(), savedRecipes: z.array(z.record(z.unknown())).max(20).optional() });
export const requestSchema = z.object({ message: z.string().trim().min(1).max(4000), recipe: z.record(z.unknown()).optional(), session: z.record(z.unknown()).optional(), conversationId: z.string().uuid().optional(), localContext: localContextSchema.optional() });

const string = { type: 'string' };
const arrayOfStrings = { type: 'array', items: string };
const object = (properties: Record<string, unknown>) => ({ type: 'object', properties, required: Object.keys(properties), additionalProperties: false });
const recipeJSONSchema = object({
  name: string, description: string, cuisine: string, category: string,
  ingredients: { type: 'array', items: object({ id: string, name: string, quantity: { type: 'number' }, unit: string }) },
  steps: { type: 'array', items: object({ id: string, title: string, instruction: string, durationSeconds: { type: ['integer', 'null'] }, ingredients: arrayOfStrings }) },
  equipment: arrayOfStrings, prepMinutes: { type: 'integer' }, cookMinutes: { type: 'integer' }, difficulty: { type: 'integer' }, servings: { type: 'integer' }, skills: arrayOfStrings, notes: string,
});
export const replyJSONSchema = object({ kind: { type: 'string', enum: ['guidance', 'recipe'] }, message: string, recipe: { anyOf: [recipeJSONSchema, { type: 'null' }] }, safetyNote: { type: ['string', 'null'] } });
