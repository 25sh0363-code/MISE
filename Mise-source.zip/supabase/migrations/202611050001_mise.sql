-- MISE: private user records, append-only recipe versions, optimistic synchronization.
-- Local SQLite remains usable without this migration or an account.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Chef' check (char_length(display_name) between 1 and 100),
  created_at timestamptz not null default now()
);
create table public.preferences (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  revision bigint not null default 1 check (revision > 0),
  deleted_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);
create table public.recipes (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  name text generated always as (payload #>> '{recipe,name}') stored,
  revision bigint not null default 1 check (revision > 0),
  deleted_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, id),
  check (deleted_at is not null or (char_length(name) between 1 and 200 and jsonb_typeof(payload #> '{recipe,ingredients}') = 'array' and jsonb_typeof(payload #> '{recipe,steps}') = 'array'))
);
create table public.recipe_versions (
  user_id uuid not null,
  recipe_id text not null,
  version bigint not null check (version > 0),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  primary key (user_id, recipe_id, version),
  foreign key (user_id, recipe_id) references public.recipes(user_id, id) on delete cascade
);
create table public.recipe_ingredients (
  user_id uuid not null,
  recipe_id text not null,
  id text not null,
  position integer not null check (position >= 0),
  name text not null check (char_length(name) between 1 and 200),
  quantity numeric not null check (quantity > 0),
  unit text not null,
  primary key (user_id, recipe_id, id),
  foreign key (user_id, recipe_id) references public.recipes(user_id, id) on delete cascade
);
create table public.recipe_steps (
  user_id uuid not null,
  recipe_id text not null,
  id text not null,
  position integer not null check (position >= 0),
  title text not null,
  instruction text not null check (char_length(instruction) > 0),
  duration_seconds integer check (duration_seconds between 1 and 86400),
  primary key (user_id, recipe_id, id),
  foreign key (user_id, recipe_id) references public.recipes(user_id, id) on delete cascade
);
create table public.cooking_sessions (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  status text generated always as (payload ->> 'status') stored,
  revision bigint not null default 1 check (revision > 0),
  deleted_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, id),
  check (status in ('preparing', 'cooking', 'paused', 'reviewing', 'completed', 'abandoned'))
);
create table public.journal_entries (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  session_id text generated always as (payload ->> 'sessionId') stored,
  revision bigint not null default 1 check (revision > 0),
  deleted_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, id),
  unique (user_id, session_id),
  check (session_id is not null),
  check ((payload ->> 'durationSeconds')::numeric >= 0),
  check ((payload ->> 'xp')::integer between 0 and 1000),
  check ((payload #>> '{ratings,overall}')::integer between 1 and 5)
);
create table public.cooking_photos (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  journal_entry_id text,
  entity_id text not null,
  storage_path text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, id),
  check (split_part(storage_path, '/', 1) = user_id::text)
);
create table public.culinary_skills (
  id text primary key,
  name text unique not null
);
create table public.user_skills (
  user_id uuid not null references auth.users(id) on delete cascade,
  skill_id text not null references public.culinary_skills(id),
  practice_count integer not null default 0 check (practice_count >= 0),
  xp integer not null default 0 check (xp >= 0),
  primary key (user_id, skill_id)
);
create table public.achievements (
  id text primary key,
  name text not null,
  description text not null,
  target integer not null check (target > 0)
);
create table public.user_achievements (
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_id text not null references public.achievements(id),
  earned_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);
create table public.challenges (
  id text primary key,
  name text not null,
  description text not null,
  cadence text not null check (cadence in ('daily', 'weekly')),
  target integer not null check (target > 0),
  reward_xp integer not null check (reward_xp >= 0),
  starts_at timestamptz,
  ends_at timestamptz,
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);
create table public.user_challenges (
  user_id uuid not null references auth.users(id) on delete cascade,
  challenge_id text not null references public.challenges(id),
  period_start date not null,
  progress integer not null default 0 check (progress >= 0),
  completed_at timestamptz,
  primary key (user_id, challenge_id, period_start)
);
create table public.culinary_journeys (
  id text primary key,
  name text not null,
  description text not null
);
create table public.journey_recipes (
  journey_id text not null references public.culinary_journeys(id) on delete cascade,
  recipe_id text not null,
  position integer not null check (position >= 0),
  primary key (journey_id, recipe_id),
  unique (journey_id, position)
);
create table public.ai_conversations (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, id)
);
create table public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  conversation_id uuid not null,
  role text not null check (role in ('user', 'assistant')),
  content text not null check (char_length(content) between 1 and 16000),
  structured_response jsonb,
  created_at timestamptz not null default now(),
  foreign key (user_id, conversation_id) references public.ai_conversations(user_id, id) on delete cascade
);
create table public.sync_mutation_receipts (
  user_id uuid not null references auth.users(id) on delete cascade,
  mutation_id text not null,
  result jsonb not null,
  created_at timestamptz not null default now(),
  primary key (user_id, mutation_id)
);
create table public.chef_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_day date not null,
  count integer not null default 0,
  minute_start timestamptz not null default now(),
  minute_count integer not null default 0,
  primary key (user_id, usage_day)
);

create index recipes_user_updated on public.recipes(user_id, updated_at);
create index recipes_name_search on public.recipes using gin(to_tsvector('simple', coalesce(name, '')));
create index sessions_user_updated on public.cooking_sessions(user_id, updated_at);
create index journal_user_updated on public.journal_entries(user_id, updated_at desc);
create index photos_journal on public.cooking_photos(user_id, journal_entry_id);
create index ai_messages_conversation on public.ai_messages(user_id, conversation_id, created_at);

-- Every user-owned table is private. Catalogs are read-only to clients.
do $$
declare t text;
begin
  foreach t in array array['cooking_photos','user_skills','user_achievements','user_challenges','ai_conversations','ai_messages'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('create policy owner_access on public.%I for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)', t);
  end loop;
  -- Sync-managed records are readable directly, but every client write must
  -- use the compare-and-swap RPC. This also protects normalized child rows.
  foreach t in array array['preferences','recipes','recipe_ingredients','recipe_steps','cooking_sessions','journal_entries'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke insert, update, delete on public.%I from anon, authenticated', t);
    execute format('grant select on public.%I to authenticated', t);
    execute format('create policy owner_read on public.%I for select to authenticated using ((select auth.uid()) = user_id)', t);
  end loop;
  foreach t in array array['culinary_skills','achievements','challenges','culinary_journeys','journey_recipes'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('grant select on public.%I to anon, authenticated', t);
    execute format('create policy catalog_read on public.%I for select to anon, authenticated using (true)', t);
  end loop;
end $$;
revoke insert, update, delete on public.recipe_versions from anon, authenticated;
grant select on public.recipe_versions to authenticated;
grant select, insert, update, delete on public.profiles to authenticated;
grant select on public.sync_mutation_receipts, public.chef_usage to authenticated;
alter table public.recipe_versions enable row level security;
create policy versions_read on public.recipe_versions for select to authenticated using ((select auth.uid()) = user_id);
alter table public.profiles enable row level security;
create policy profile_owner on public.profiles for all to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
alter table public.sync_mutation_receipts enable row level security;
create policy receipts_read on public.sync_mutation_receipts for select to authenticated using ((select auth.uid()) = user_id);
alter table public.chef_usage enable row level security;
create policy usage_read on public.chef_usage for select to authenticated using ((select auth.uid()) = user_id);

-- Compare-and-swap is atomic, retryable and idempotent. An old client cannot
-- silently overwrite another device's edit. Tombstones prevent resurrection.
create function public.sync_mise_mutation(
  p_mutation_id text, p_entity text, p_entity_id text, p_operation text,
  p_payload jsonb, p_expected_revision bigint
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := auth.uid();
  existing record;
  current_revision bigint := 0;
  next_revision bigint;
  result jsonb;
  ingredient jsonb;
  step jsonb;
  item_position integer;
begin
  if uid is null then raise exception 'Authentication required'; end if;
  if p_entity is null or p_operation is null or p_entity not in ('recipes','cooking_sessions','journal_entries','preferences') or p_operation not in ('upsert','delete') then raise exception 'Invalid mutation'; end if;
  if p_mutation_id is null or p_entity_id is null or p_expected_revision is null or char_length(p_mutation_id) not between 1 and 150 or char_length(p_entity_id) not between 1 and 150 or p_expected_revision < 0 then raise exception 'Invalid mutation identity'; end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' or octet_length(p_payload::text) > 500000 then raise exception 'Invalid mutation payload'; end if;
  perform pg_advisory_xact_lock(hashtextextended(uid::text || p_entity || p_entity_id, 0));
  select r.result into result from public.sync_mutation_receipts r where r.user_id = uid and r.mutation_id = p_mutation_id;
  if found then return result; end if;
  execute format('select revision, payload, deleted_at from public.%I where user_id = $1 and id = $2 for update', p_entity) into existing using uid, p_entity_id;
  if existing.revision is not null then current_revision := existing.revision; end if;
  if current_revision <> p_expected_revision then
    return jsonb_build_object('status','conflict','revision',current_revision,'payload',existing.payload,'deleted',existing.deleted_at is not null);
  end if;
  if p_entity = 'recipes' and (p_payload #>> '{recipe,id}') is distinct from p_entity_id then raise exception 'Recipe identity mismatch'; end if;
  if p_entity in ('cooking_sessions','journal_entries') and (p_payload ->> 'id') is distinct from p_entity_id then raise exception 'Record identity mismatch'; end if;
  next_revision := current_revision + 1;
  execute format('insert into public.%I(user_id,id,payload,revision,deleted_at,updated_at) values($1,$2,$3,$4,$5,now()) on conflict(user_id,id) do update set payload=excluded.payload,revision=excluded.revision,deleted_at=excluded.deleted_at,updated_at=now()', p_entity)
    using uid, p_entity_id, p_payload, next_revision, case when p_operation = 'delete' then now() else null end;
  if p_entity = 'recipes' then
    insert into public.recipe_versions(user_id,recipe_id,version,payload) values(uid,p_entity_id,next_revision,p_payload);
    delete from public.recipe_ingredients where user_id = uid and recipe_id = p_entity_id;
    delete from public.recipe_steps where user_id = uid and recipe_id = p_entity_id;
    if p_operation = 'upsert' then
      item_position := 0;
      for ingredient in select value from jsonb_array_elements(p_payload #> '{recipe,ingredients}') loop
        insert into public.recipe_ingredients(user_id,recipe_id,id,position,name,quantity,unit)
          values(uid,p_entity_id,ingredient->>'id',item_position,ingredient->>'name',(ingredient->>'quantity')::numeric,ingredient->>'unit');
        item_position := item_position + 1;
      end loop;
      item_position := 0;
      for step in select value from jsonb_array_elements(p_payload #> '{recipe,steps}') loop
        insert into public.recipe_steps(user_id,recipe_id,id,position,title,instruction,duration_seconds)
          values(uid,p_entity_id,step->>'id',item_position,step->>'title',step->>'instruction',(step->>'durationSeconds')::integer);
        item_position := item_position + 1;
      end loop;
    end if;
  end if;
  result := jsonb_build_object('status','applied','revision',next_revision,'payload',p_payload,'deleted',p_operation='delete');
  insert into public.sync_mutation_receipts(user_id,mutation_id,result) values(uid,p_mutation_id,result);
  return result;
end $$;
revoke all on function public.sync_mise_mutation(text,text,text,text,jsonb,bigint) from public;
grant execute on function public.sync_mise_mutation(text,text,text,text,jsonb,bigint) to authenticated;

-- Requests are authenticated and limited before provider costs are incurred.
create function public.consume_chef_quota() returns boolean language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); usage public.chef_usage%rowtype;
begin
  if uid is null then return false; end if;
  insert into public.chef_usage(user_id,usage_day) values(uid,current_date) on conflict do nothing;
  select * into usage from public.chef_usage where user_id=uid and usage_day=current_date for update;
  if usage.count >= 30 then return false; end if;
  if usage.minute_start < now() - interval '1 minute' then
    usage.minute_count := 0; usage.minute_start := now();
  end if;
  if usage.minute_count >= 6 then return false; end if;
  update public.chef_usage set count=count+1,minute_count=usage.minute_count+1,minute_start=usage.minute_start where user_id=uid and usage_day=current_date;
  return true;
end $$;
revoke all on function public.consume_chef_quota() from public;
grant execute on function public.consume_chef_quota() to authenticated;

insert into public.culinary_skills(id,name) values
 ('knife-skills','Knife Skills'),('heat-control','Heat Control'),('seasoning','Seasoning'),('sauces','Sauces'),('baking','Baking'),('dough-handling','Dough Handling'),('food-preparation','Food Preparation'),('presentation','Presentation'),('timing','Timing'),('culinary-creativity','Culinary Creativity');
insert into public.achievements(id,name,description,target) values
 ('first-flame','First Flame','Complete your first recipe.',1),
 ('sauce-apprentice','Sauce Apprentice','Prepare five different sauces.',5),
 ('kitchen-explorer','Kitchen Explorer','Cook ten different recipes.',10),
 ('around-the-world','Around the World','Cook recipes from five cuisines.',5),
 ('signature-dish','Signature Dish','Create and refine an original recipe.',3);
insert into public.challenges(id,name,description,cadence,target,reward_xp) values
 ('crispy-challenge','The Crispy Challenge','Cook fries and record what made them crisp. Never rush hot oil.','daily',1,40),
 ('sauce-explorer','Sauce Explorer','Practise three different homemade sauces.','weekly',3,90),
 ('burger-workshop','Burger Workshop','Cook a burger and document a topping variation.','weekly',1,60);
insert into public.culinary_journeys(id,name,description) values
 ('burger-workshop','The Burger Workshop','Build confidence with burgers, sauces and crispy fries.'),
 ('pasta-foundations','Pasta Foundations','Learn to season water and finish a simple pasta sauce.'),
 ('breakfast-adventures','Breakfast Adventures','Practise eggs, timing and a relaxed morning meal.'),
 ('street-food-explorer','Street Food Explorer','Explore portable food from different culinary traditions.'),
 ('baking-basics','Baking Basics','Understand measuring, mixing and oven temperature.'),
 ('art-of-sauces','The Art of Sauces','Explore emulsions, reductions and balanced seasoning.');

insert into public.journey_recipes(journey_id,recipe_id,position) values
 ('burger-workshop','classic-cheeseburger',0),('burger-workshop','homemade-burger-sauce',1),('burger-workshop','crispy-french-fries',2),('burger-workshop','caramelized-onions',3),('burger-workshop','gourmet-burger-fries',4);

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('cooking-photos','cooking-photos',false,10485760,array['image/jpeg','image/png','image/webp','image/heic'])
 on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
create policy photos_select on storage.objects for select to authenticated using (bucket_id='cooking-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy photos_insert on storage.objects for insert to authenticated with check (bucket_id='cooking-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy photos_update on storage.objects for update to authenticated using (bucket_id='cooking-photos' and (storage.foldername(name))[1]=(select auth.uid())::text) with check (bucket_id='cooking-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy photos_delete on storage.objects for delete to authenticated using (bucket_id='cooking-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
