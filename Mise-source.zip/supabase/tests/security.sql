-- Run AFTER the MISE migration on a disposable Supabase project as postgres.
-- All fixtures roll back. A raised exception indicates a failing check.
begin;
insert into auth.users(id,email) values
 ('d1a15e00-0000-4000-8000-000000000001','mise-test-one@example.invalid'),
 ('d1a15e00-0000-4000-8000-000000000002','mise-test-two@example.invalid');
set local role authenticated;
select set_config('request.jwt.claim.sub','d1a15e00-0000-4000-8000-000000000001',true);

do $$
declare
  payload jsonb := '{"recipe":{"id":"test-recipe","name":"Test soup","description":"A fixture, not starter content","ingredients":[{"id":"water","name":"Water","quantity":250,"unit":"ml"}],"steps":[{"id":"one","title":"Warm","instruction":"Warm the water"}]},"saved":true,"favorite":false,"archived":false,"revision":1}';
  answer jsonb;
  rejected boolean := false;
begin
  answer := public.sync_mise_mutation('mise-test-mutation-1','recipes','test-recipe','upsert',payload,0);
  if answer->>'status' <> 'applied' or (answer->>'revision')::integer <> 1 then raise exception 'Initial mutation did not apply'; end if;
  answer := public.sync_mise_mutation('mise-test-mutation-1','recipes','test-recipe','upsert',payload,0);
  if answer->>'status' <> 'applied' or (answer->>'revision')::integer <> 1 then raise exception 'Retry was not idempotent'; end if;
  if (select count(*) from public.recipe_versions where recipe_id='test-recipe') <> 1 then raise exception 'Retry duplicated recipe versions'; end if;
  answer := public.sync_mise_mutation('mise-test-mutation-2','recipes','test-recipe','upsert',payload,0);
  if answer->>'status' <> 'conflict' or (answer->>'revision')::integer <> 1 then raise exception 'Stale revision overwrote remote data'; end if;
  begin
    perform public.sync_mise_mutation('mise-test-null','recipes','test-recipe','upsert',payload,null);
  exception when others then rejected := true;
  end;
  if not rejected then raise exception 'NULL revision bypassed optimistic concurrency'; end if;
  payload := jsonb_set(payload,'{recipe,name}','"Updated soup"'::jsonb);
  answer := public.sync_mise_mutation('mise-test-mutation-3','recipes','test-recipe','upsert',payload,1);
  if (answer->>'revision')::integer <> 2 then raise exception 'Revision was not advanced'; end if;
  if (select v.payload#>>'{recipe,name}' from public.recipe_versions v where v.recipe_id='test-recipe' and v.version=1) <> 'Test soup' then raise exception 'Old version was changed'; end if;
  if (select count(*) from public.recipe_versions where recipe_id='test-recipe') <> 2 then raise exception 'New version missing'; end if;
  -- Ordinary client table writes cannot bypass the revision/receipt RPC.
  rejected := false;
  begin
    update public.recipes r set payload=jsonb_set(r.payload,'{recipe,name}','"Bypassed RPC"'::jsonb) where r.id='test-recipe';
  exception when insufficient_privilege then rejected := true;
  end;
  if not rejected then raise exception 'Direct recipe update was not denied'; end if;
  rejected := false;
  begin
    delete from public.recipe_versions where recipe_id='test-recipe';
  exception when insufficient_privilege then rejected := true;
  end;
  if not rejected then raise exception 'Recipe versions were not read-only'; end if;
  rejected := false;
  begin
    insert into public.preferences(user_id,id,payload) values(auth.uid(),'bypass-test','{}'::jsonb);
  exception when insufficient_privilege then rejected := true;
  end;
  if not rejected then raise exception 'Direct preference insert bypassed RPC'; end if;

end $$;

select set_config('request.jwt.claim.sub','d1a15e00-0000-4000-8000-000000000002',true);
do $$
begin
  if (select count(*) from public.recipes where id='test-recipe') <> 0 then raise exception 'RLS leaked another user recipe'; end if;
  if (select count(*) from public.recipe_versions where recipe_id='test-recipe') <> 0 then raise exception 'RLS leaked another user recipe history'; end if;
  if (select count(*) from public.sync_mutation_receipts) <> 0 then raise exception 'RLS leaked mutation receipts'; end if;
  begin
    insert into public.profiles(id,display_name) values('d1a15e00-0000-4000-8000-000000000001','Should fail');
    raise exception 'RLS allowed another user profile write';
  exception when insufficient_privilege then null;
  end;
end $$;

select set_config('request.jwt.claim.sub','',true);
do $$
declare rejected boolean := false;
begin
  begin
    perform public.sync_mise_mutation('mise-test-unauthorized','preferences','preferences','upsert','{}'::jsonb,0);
  exception when others then rejected := true;
  end;
  if not rejected then raise exception 'Mutation accepted no authenticated user'; end if;
  if public.consume_chef_quota() then raise exception 'Chef quota accepted no authenticated user'; end if;
end $$;
rollback;
