import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMise } from '../state/app';
import { useTheme } from '../theme';
import { challengeProgress } from '../domain/challenges';
import { Text, Button, Progress } from './ui';
export function ChallengeList({ compact = false }: {
    compact?: boolean;
}) {
    const { snapshot, act, notify } = useMise();
    const { colors } = useTheme();
    if (!snapshot)
        return null;
    const challenges = challengeProgress(snapshot.journal, snapshot.preferences);
    return <View style={{ gap: 20 }}>{challenges.slice(0, compact ? 1 : challenges.length).map(c => <View key={c.id} style={{ paddingVertical: 12, gap: 12 }}><View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}><Ionicons name={c.completed ? 'checkmark-circle-outline' : 'flame-outline'} color={c.completed ? colors.primary : colors.accent} size={26}/><Text variant="heading" style={{ flex: 1 }}>{c.name}</Text></View><Text color={colors.muted}>{c.description}</Text><Text variant="caption" color={colors.muted}>{c.period === 'daily' ? 'Daily' : 'Weekly'} · +{c.xp} XP for recorded practice</Text>{c.enrolled && <><Progress value={c.target ? c.progress / c.target : 0}/><Text variant="caption" color={colors.primary}>{c.completed ? 'Completed · bonus awarded' : `${c.progress} of ${c.target} · in progress`}</Text></>}{!c.enrolled ? <Button label="Join this challenge" variant="secondary" onPress={() => { void act(r => r.enrollChallenge(c.id)).then(() => notify('You’re in. Cook at your own pace and save your review.')).catch(() => { }); }}/> : !c.completed ? <Button label="Find something to cook" variant="ghost" onPress={() => router.push('/discover')}/> : null}</View>)}<Text variant="caption" color={colors.muted}>Optional, always. Cook to doneness and take your time. Challenges never reward speed.</Text></View>;
}
