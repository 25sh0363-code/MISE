import { useEffect, useState } from 'react';
import { View, Modal, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useMise } from '../state/app';
import { useTheme } from '../theme';
import type { Conflict } from '../domain/types';
import { Text, Button, Section, Divider } from './ui';
function summary(raw: string) {
    try {
        const parsed = JSON.parse(raw);
        const entry = parsed.payload ?? parsed;
        if (parsed.deleted)
            return 'This copy was deleted in the cloud.';
        if (entry.recipe) {
            const r = entry.recipe;
            return `${r.name}\n${r.description || ''}\n${r.ingredients?.length || 0} ingredients · ${r.steps?.length || 0} steps\n${r.notes || ''}`;
        }
        ;
        if (entry.recipeName)
            return `${entry.recipeName}\n${entry.notes || 'No personal notes.'}\n${entry.improvements || ''}\nOverall rating: ${entry.ratings?.overall ?? '—'}/5`;
        if (entry.experience)
            return `${entry.experience}\nCuisines: ${entry.cuisines?.join(', ') || 'Any'}\nAllergies: ${entry.allergies || 'None recorded'}\nGoals: ${entry.goals?.join(', ') || 'None recorded'}`;
        if (entry.status)
            return `${entry.recipe?.name || 'Cooking session'}\n${entry.status} · step ${(entry.stepIndex || 0) + 1}`;
        return 'This copy contains saved kitchen data.';
    }
    catch {
        return 'This copy could not be read. Keep it preserved and retry synchronization.';
    }
}
export function ConflictReview() {
    const { snapshot, repo, act, notify } = useMise();
    const { colors } = useTheme();
    const [conflicts, setConflicts] = useState<Conflict[]>([]);
    const [open, setOpen] = useState(false);
    const [error, setError] = useState('');
    useEffect(() => { if (!repo)
        return; void repo.listConflicts().then(setConflicts).catch(e => setError(e.message)); }, [repo, snapshot?.conflicts]);
    const resolve = (conflict: Conflict, choice: 'local' | 'remote') => Alert.alert(choice === 'local' ? 'Keep your device copy?' : 'Use the cloud copy?', 'This chooses the version to use for this item. Review both copies carefully before continuing.', [{ text: 'Keep reviewing', style: 'cancel' }, { text: choice === 'local' ? 'Keep device copy' : 'Use cloud copy', onPress: () => { void act(r => r.resolveConflict(conflict.id, choice)).then(async () => { setConflicts(await repo.listConflicts()); notify('Your choice is saved. Sync again to finish updating your cloud kitchen.'); }).catch(() => { }); } }]);
    if (!snapshot?.conflicts && !error)
        return null;
    return <View style={{ gap: 12 }}>{error && <Text color={colors.danger}>{error}</Text>}<Text color={colors.muted}>Some items changed on two devices. Both copies have been kept for your review.</Text><Button label={`Review ${snapshot?.conflicts || 0} sync conflicts`} variant="secondary" onPress={() => setOpen(true)}/><Modal visible={open} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setOpen(false)}><SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}><ScrollView contentContainerStyle={{ padding: 24, gap: 22 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 16, alignItems: 'center' }}><Text variant="title" style={{ flex: 1 }}>Choose your copy</Text><Button label="Done" variant="ghost" onPress={() => setOpen(false)}/></View><Text color={colors.muted}>We kept these changes rather than silently replacing them. Choose which copy to use.</Text>{conflicts.map(c => <View key={c.id} style={{ gap: 14 }}><Text variant="heading">{c.entity === 'recipes' ? 'Recipe' : c.entity === 'preferences' ? 'Cooking preferences' : c.entity === 'journal_entries' ? 'Journal entry' : 'Cooking session'}</Text><View style={{ padding: 18, gap: 10, backgroundColor: colors.surface, borderRadius: 14 }}><Text variant="label">On this device</Text><Text selectable>{summary(c.localPayload)}</Text><Button label="Keep device copy" variant="secondary" onPress={() => resolve(c, 'local')}/></View><View style={{ padding: 18, gap: 10, backgroundColor: colors.surface, borderRadius: 14 }}><Text variant="label">In your cloud kitchen</Text><Text selectable>{summary(c.remotePayload)}</Text><Button label="Use cloud copy" variant="secondary" onPress={() => resolve(c, 'remote')}/></View><Divider /></View>)}{conflicts.length === 0 && <Text>All conflicts have been reviewed.</Text>}</ScrollView></SafeAreaView></Modal></View>;
}
