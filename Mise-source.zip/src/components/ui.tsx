import React, { ReactNode, useEffect } from 'react';
import { View, Text as RNText, TextProps, Pressable, StyleSheet, ScrollView, TextInput, TextInputProps, Image, ViewStyle, Platform, ActivityIndicator, StyleProp } from 'react-native';
import { SafeAreaView, type Edge } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useAnimatedStyle, useSharedValue, withTiming, useReducedMotion } from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../theme';
import type { Recipe } from '../domain/types';
export type IconName = React.ComponentProps<typeof Ionicons>['name'];
export function Text({ variant = 'body', color, style, ...props }: TextProps & {
    variant?: 'display' | 'title' | 'heading' | 'body' | 'caption' | 'label';
    color?: string;
}) { const { colors } = useTheme(); return <RNText {...props} style={[{ color: color || colors.text }, type[variant], style]}/>; }
const type = StyleSheet.create({ display: { fontSize: 36, lineHeight: 41, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', letterSpacing: -.6 }, title: { fontSize: 28, lineHeight: 34, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' }, heading: { fontSize: 21, lineHeight: 28, fontWeight: '600' }, body: { fontSize: 17, lineHeight: 25 }, caption: { fontSize: 13, lineHeight: 19 }, label: { fontSize: 15, lineHeight: 21, fontWeight: '600' } });
export function Screen({ children, scroll = true, padded = true, edges = ['top', 'left', 'right'] }: {
    children: ReactNode;
    scroll?: boolean;
    padded?: boolean;
    edges?: Edge[];
}) { const { colors } = useTheme(); const content = { paddingHorizontal: padded ? 24 : 0, paddingTop: 12, paddingBottom: 40, gap: 20 }; return <SafeAreaView edges={edges} style={{ flex: 1, backgroundColor: colors.background }}>{scroll ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={content}>{children}</ScrollView> : <View className="flex-1" style={[content]}>{children}</View>}</SafeAreaView>; }
export function Button({ label, onPress, variant = 'primary', icon, disabled, loading }: {
    label: string;
    onPress: () => void;
    variant?: 'primary' | 'secondary' | 'ghost';
    icon?: IconName;
    disabled?: boolean;
    loading?: boolean;
}) { const { colors } = useTheme(); const foreground = variant === 'primary' ? colors.onPrimary : colors.primary; return <Pressable accessibilityRole="button" accessibilityState={{ disabled: disabled || loading }} disabled={disabled || loading} onPress={() => { void Haptics.selectionAsync().catch(() => { }); onPress(); }} className="min-h-[52px] flex-row items-center justify-center gap-2 rounded-[14px] px-5 py-3.5" style={({ pressed }) => ({ backgroundColor: variant === 'primary' ? colors.primary : variant === 'secondary' ? colors.surface : 'transparent', opacity: disabled ? .45 : pressed ? .7 : 1 })}>{loading ? <ActivityIndicator color={foreground}/> : icon ? <Ionicons name={icon} size={20} color={foreground}/> : null}<Text variant="label" color={foreground} style={{ textAlign: 'center' }}>{label}</Text></Pressable>; }
export function IconButton({ name, onPress, label }: {
    name: IconName;
    onPress: () => void;
    label: string;
}) { const { colors } = useTheme(); return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => ({ minWidth: 48, minHeight: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface, opacity: pressed ? .6 : 1 })}><Ionicons name={name} color={colors.primary} size={22}/></Pressable>; }
export function Section({ title, action, onAction, children }: {
    title: string;
    action?: string;
    onAction?: () => void;
    children: ReactNode;
}) { const { colors } = useTheme(); return <View className="mt-2.5 gap-3.5"><View className="flex-row items-center justify-between gap-3"><Text variant="title" style={{ flex: 1 }}>{title}</Text>{action && <Pressable onPress={onAction} accessibilityRole="button" style={{ minHeight: 48, justifyContent: 'center' }}><Text variant="label" color={colors.primary}>{action}</Text></Pressable>}</View>{children}</View>; }
export function Chip({ label, selected = false, onPress }: {
    label: string;
    selected?: boolean;
    onPress?: () => void;
}) { const { colors } = useTheme(); return <Pressable onPress={onPress} disabled={!onPress} accessibilityRole={onPress ? 'button' : undefined} accessibilityState={{ selected }} style={{ borderRadius: 24, minHeight: onPress ? 48 : 30, paddingHorizontal: 16, paddingVertical: onPress ? 12 : 5, backgroundColor: selected ? colors.primary : colors.surface, alignSelf: 'flex-start', justifyContent: 'center' }}><Text variant="caption" color={selected ? colors.onPrimary : colors.muted}>{label}</Text></Pressable>; }
export function Field({ label, style, ...props }: TextInputProps & {
    label: string;
}) { const { colors } = useTheme(); return <View className="gap-2"><Text variant="label">{label}</Text><TextInput {...props} accessibilityLabel={label} placeholderTextColor={colors.muted} style={[{ minHeight: 52, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 14, color: colors.text, fontSize: 17, backgroundColor: colors.paper, textAlignVertical: props.multiline ? 'top' : 'center' }, style]}/></View>; }
export function Progress({ value, color, trackColor }: {
    value: number;
    color?: string;
    trackColor?: string;
}) { const { colors } = useTheme(); const reduced = useReducedMotion(); const progress = useSharedValue(0); useEffect(() => { progress.value = withTiming(Math.max(0, Math.min(1, value)), { duration: reduced ? 0 : 500 }); }, [value, reduced, progress]); const style = useAnimatedStyle(() => ({ width: `${progress.value * 100}%` })); return <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: Math.round(value * 100) }} style={{ height: 6, borderRadius: 3, backgroundColor: trackColor || colors.border, overflow: 'hidden' }}><Animated.View style={[{ height: 6, backgroundColor: color || colors.primary, borderRadius: 3 }, style]}/></View>; }
const symbols: Record<string, IconName> = { burger: 'restaurant-outline', fries: 'flame-outline', sauce: 'water-outline', onions: 'leaf-outline', gourmet: 'restaurant-outline', custom: 'book-outline', pasta: 'restaurant-outline', eggs: 'sunny-outline', salad: 'leaf-outline' };
export function RecipeArtwork({ recipe, style }: {
    recipe: Recipe;
    style?: StyleProp<ViewStyle>;
}) { const { colors } = useTheme(); if (recipe.imageUri)
    return <Image source={{ uri: recipe.imageUri }} accessibilityLabel={recipe.name} style={[{ width: '100%', height: 220 }, style] as any}/>; if (recipe.imageKey === 'pasta')
    return <Image source={require('../../assets/images/pasta.png')} accessibilityLabel="Tomato and basil pasta" style={[{ width: '100%', height: 220 }, style] as any}/>; if (recipe.imageKey === 'burger' || recipe.imageKey === 'gourmet')
    return <Image source={require('../../assets/images/burger.png')} accessibilityLabel="Classic cheeseburger with golden fries" style={[{ width: '100%', height: 220 }, style] as any}/>; return <View style={[{ height: 180, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', gap: 12 }, style]}><Ionicons name={symbols[recipe.imageKey] || 'restaurant-outline'} color={colors.primary} size={55}/><Text variant="caption" color={colors.muted}>{recipe.cuisine} · {recipe.category}</Text></View>; }
export function RecipeCard({ recipe, saved, onPress, onSave, compact = false }: {
    recipe: Recipe;
    saved?: boolean;
    onPress: () => void;
    onSave?: () => void;
    compact?: boolean;
}) { const { colors } = useTheme(); const reduced = useReducedMotion(); const translation = useSharedValue(0); const swipeStyle = useAnimatedStyle(() => ({ transform: [{ translateX: translation.value }] })); const swipe = Gesture.Pan().enabled(!!onSave).activeOffsetX([-35, 35]).failOffsetY([-15, 15]).runOnJS(true).onUpdate(e => { if (!reduced)
    translation.value = Math.max(-45, Math.min(45, e.translationX / 3)); }).onEnd(e => { if (Math.abs(e.translationX) > 70 && onSave) {
    void Haptics.selectionAsync().catch(() => { });
    if (saved) onPress(); else onSave();
} translation.value = withTiming(0, { duration: reduced ? 0 : 160 }); }).onFinalize(() => { translation.value = withTiming(0, { duration: reduced ? 0 : 160 }); }); return <GestureDetector gesture={swipe}><Animated.View style={[{ borderRadius: 16, overflow: 'hidden', backgroundColor: colors.paper }, swipeStyle]}><Pressable accessibilityRole="button" accessibilityLabel={`View ${recipe.name}`} onPress={onPress}><RecipeArtwork recipe={recipe} style={{ height: compact ? 135 : 225 }}/><View className="gap-2 p-[18px]"><Text variant={compact ? 'heading' : 'title'}>{recipe.name}</Text><Text variant="caption" color={colors.muted}>{recipe.prepMinutes + recipe.cookMinutes} min · {recipe.cuisine} · Difficulty {recipe.difficulty}/5</Text>{!compact && <Text color={colors.muted} numberOfLines={2}>{recipe.description}</Text>}</View></Pressable>{onSave && <Pressable onPress={saved ? onPress : onSave} accessibilityRole="button" accessibilityLabel={saved ? 'Open saved recipe' : 'Save to cookbook'} style={{ position: 'absolute', right: 12, top: 12, width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.paper }}><Ionicons name={saved ? 'bookmark' : 'bookmark-outline'} size={22} color={colors.primary}/></Pressable>}</Animated.View></GestureDetector>; }
export function Empty({ title, description, action, onAction, icon = 'book-outline' }: {
    title: string;
    description: string;
    action?: string;
    onAction?: () => void;
    icon?: IconName;
}) { const { colors } = useTheme(); return <View className="items-start gap-3.5 py-7"><Ionicons name={icon} size={38} color={colors.primary}/><Text variant="title">{title}</Text><Text color={colors.muted}>{description}</Text>{action && onAction && <Button label={action} onPress={onAction}/>}</View>; }
export function Divider() { const { colors } = useTheme(); return <View style={{ height: 1, backgroundColor: colors.border, marginVertical: 4 }}/>; }
