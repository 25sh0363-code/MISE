import { Directory, File, Paths } from 'expo-file-system';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { MiseRepository } from '../db/repository';
import type { SyncEntity } from '../domain/types';
import { getCloudClient, localModeMessage } from './cloud';
export type SyncResult = {
    pushed: number;
    pulled: number;
    photos: number;
    conflicts: number;
};
const entities: SyncEntity[] = ['recipes', 'preferences', 'cooking_sessions', 'journal_entries'];
const storagePrefix = 'storage://cooking-photos/';
let running: Promise<SyncResult> | null = null;
// A single in-flight run prevents two foreground/connectivity events from
// acknowledging the same queue in different orders.
export function syncNow(repo: MiseRepository): Promise<SyncResult> {
    if (!running)
        running = runSync(repo).finally(() => { running = null; });
    return running;
}
async function runSync(repo: MiseRepository): Promise<SyncResult> {
    const client = getCloudClient();
    if (!client)
        throw new Error(localModeMessage);
    const { data: { user }, error: accountError } = await client.auth.getUser();
    if (accountError || !user)
        throw new Error('Sign in and connect to the internet before synchronizing. Your local kitchen is safe.');
    await repo.bindSyncOwner(user.id);
    const result: SyncResult = { pushed: 0, pulled: 0, photos: 0, conflicts: 0 };
    for (const photo of await repo.getPendingPhotos()) {
        if (photo.ownerId && photo.ownerId !== user.id)
            throw new Error('This photograph belongs to a different local account. Sync stopped to protect it.');
        const file = new File(photo.localUri);
        if (!file.exists)
            throw new Error('A photograph waiting to sync is missing from this device. Your journal is still saved locally.');
        if (file.size > 10 * 1024 * 1024)
            throw new Error('A photograph exceeds the 10 MB upload limit. Other local data remains saved.');
        const extension = photo.localUri.split('.').pop()?.toLowerCase().replace(/[^a-z0-9]/g, '') ?? 'jpg';
        const ext = ['jpg', 'jpeg', 'png', 'webp', 'heic'].includes(extension) ? extension : 'jpg';
        const path = `${user.id}/${photo.id}.${ext}`;
        const contentType = ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : `image/${ext}`;
        const { error } = await client.storage.from('cooking-photos').upload(path, await file.arrayBuffer(), { contentType, upsert: true });
        if (error)
            throw new Error('Photo upload did not finish. It is kept on this device and will retry on the next sync.');
        const { error: metadataError } = await client.from('cooking_photos').upsert({ user_id: user.id, id: photo.id, entity_id: photo.entityId, storage_path: path }, { onConflict: 'user_id,id' });
        if (metadataError)
            throw new Error('Your photo uploaded but its record is pending. Retry sync to finish safely.');
        await repo.ackPhoto(photo.id, path);
        result.photos++;
    }
    const mappings = new Map((await repo.getPhotos()).filter(photo => photo.remotePath).map(photo => [photo.localUri, `${storagePrefix}${photo.remotePath}`]));
    // Re-fetch the head after every acknowledgement: later immutable mutations
    // have their expected revision advanced by ackMutation in the same DB commit.
    for (let count = 0; count < 1000; count++) {
        const [mutation] = await repo.getPendingMutations();
        if (!mutation)
            break;
        if (mutation.ownerId && mutation.ownerId !== user.id)
            throw new Error('The sync queue belongs to another account. Local data was preserved.');
        const payload = await mapImageReferences(JSON.parse(mutation.payload), async (value) => {
            if (value.startsWith(storagePrefix))
                return value;
            const uploaded = mappings.get(value);
            if (uploaded)
                return uploaded;
            if (/^(file|content):\/\//.test(value))
                throw new Error('A photograph is still waiting to upload. Retry sync to finish safely.');
            return value;
        });
        const { data, error } = await client.rpc('sync_mise_mutation', {
            p_mutation_id: mutation.id, p_entity: mutation.entity, p_entity_id: mutation.entityId,
            p_operation: mutation.operation, p_payload: payload, p_expected_revision: mutation.baseRevision,
        });
        if (error)
            throw new Error('Cloud sync did not finish. Pending changes remain on this device. Check the connection and Supabase migration, then retry.');
        if (!data || !Number.isSafeInteger(data.revision) || !['applied', 'conflict'].includes(data.status))
            throw new Error('The cloud returned an invalid sync acknowledgement. Local changes were kept for retry.');
        if (data.status === 'conflict') {
            const remote = data.payload ? await hydratePhotos(client, user.id, data.payload, repo, mutation.entityId) : {};
            await repo.markConflict(mutation.id, JSON.stringify({ payload: remote, revision: data.revision, deleted: Boolean(data.deleted) }));
            result.conflicts++;
        }
        else {
            await repo.ackMutation(mutation.id, data.revision);
            result.pushed++;
        }
    }
    // Full paginated pull deliberately avoids a fragile client timestamp cursor.
    // Pending/conflicted local entities are never overwritten by mergeRemote.
    for (const entity of entities) {
        for (let offset = 0;; offset += 200) {
            const { data, error } = await client.from(entity).select('id,payload,revision,deleted_at').eq('user_id', user.id).order('id', { ascending: true }).range(offset, offset + 199);
            if (error)
                throw new Error('Saved changes were sent, but cloud retrieval did not finish. Retry sync; local records are preserved.');
            for (const record of data ?? []) {
                const payload = record.deleted_at ? record.payload : await hydratePhotos(client, user.id, record.payload, repo, record.id);
                if (await repo.mergeRemote(entity, record.id, JSON.stringify(payload), record.revision, Boolean(record.deleted_at)))
                    result.pulled++;
            }
            if (!data || data.length < 200)
                break;
        }
    }
    return result;
}
async function mapImageReferences(value: unknown, map: (uri: string) => Promise<string>, key = ''): Promise<unknown> {
    if (typeof value === 'string')
        return key === 'imageUri' || key === 'photos' ? map(value) : value;
    if (Array.isArray(value))
        return Promise.all(value.map(item => mapImageReferences(item, map, key)));
    if (value && typeof value === 'object') {
        const pairs = await Promise.all(Object.entries(value).map(async ([childKey, item]) => [childKey, await mapImageReferences(item, map, childKey)]));
        return Object.fromEntries(pairs);
    }
    return value;
}
async function hydratePhotos(client: SupabaseClient, userId: string, payload: unknown, repo: MiseRepository, entityId: string): Promise<unknown> {
    const directory = new Directory(Paths.document, 'cloud-photos', userId);
    directory.create({ intermediates: true, idempotent: true });
    const downloads = new Map<string, Promise<string>>();
    return mapImageReferences(payload, async (reference) => {
        if (!reference.startsWith(storagePrefix)) {
            if (/^(file|content):\/\//.test(reference))
                throw new Error('A cloud photograph has an unsupported device-only reference. Your local data was preserved.');
            return reference;
        }
        const existingDownload = downloads.get(reference);
        if (existingDownload)
            return existingDownload;
        const download = (async () => {
            const path = reference.slice(storagePrefix.length);
            if (!path.startsWith(`${userId}/`) || path.includes('..'))
                throw new Error('A cloud photograph has an invalid ownership path. Sync stopped safely.');
            const name = path.slice(userId.length + 1).replace(/[^a-zA-Z0-9._-]/g, '_');
            const target = new File(directory, name);
            if (target.exists && target.size > 0) {
                await repo.registerDownloadedPhoto(target.uri, path, entityId);
                return target.uri;
            }
            const { data, error } = await client.storage.from('cooking-photos').createSignedUrl(path, 120);
            if (error || !data?.signedUrl)
                throw new Error('A cloud photo could not be retrieved. Retry sync to make it available offline.');
            const temporary = new File(directory, `${name}.partial`);
            if (temporary.exists)
                temporary.delete();
            const downloaded = await File.downloadFileAsync(data.signedUrl, temporary, { idempotent: true });
            if (!downloaded.exists || downloaded.size < 1)
                throw new Error('A photo download was interrupted. Retry sync.');
            downloaded.move(target);
            await repo.registerDownloadedPhoto(target.uri, path, entityId);
            return target.uri;
        })();
        downloads.set(reference, download);
        return download;
    });
}
