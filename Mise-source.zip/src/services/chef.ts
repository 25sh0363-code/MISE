import { z } from 'zod';
import type { Recipe, Session, Preferences, JournalEntry } from '../domain/types';
import { getCloudClient, localModeMessage } from './cloud';
const ingredientSchema = z.object({ id: z.string().min(1), name: z.string().min(1).max(200), quantity: z.number().positive().max(100000), unit: z.string().max(50) });
const stepSchema = z.object({ id: z.string().min(1), title: z.string().min(1).max(150), instruction: z.string().min(1).max(4000), durationSeconds: z.number().int().positive().max(86400).optional(), ingredients: z.array(z.string()).optional() });
export const aiRecipeSchema = z.object({
    id: z.string().min(1), name: z.string().min(1).max(150), description: z.string().min(1).max(2000),
    cuisine: z.string().min(1).max(80), category: z.string().min(1).max(80), imageKey: z.literal('custom'),
    ingredients: z.array(ingredientSchema).min(1).max(60), steps: z.array(stepSchema).min(1).max(40),
    equipment: z.array(z.string().max(100)).min(1).max(30), prepMinutes: z.number().int().nonnegative().max(2880),
    cookMinutes: z.number().int().nonnegative().max(2880), difficulty: z.number().int().min(1).max(5),
    servings: z.number().int().min(1).max(100), skills: z.array(z.string().max(100)).max(15),
    notes: z.string().max(4000).optional(), source: z.literal('ai'),
});
const replySchema = z.object({ kind: z.enum(['guidance', 'recipe']), message: z.string().min(1).max(12000), recipe: aiRecipeSchema.optional(), safetyNote: z.string().max(2000).optional(), conversationId: z.string().optional() });
export type ChefReply = {
    message: string;
    kind: 'guidance' | 'recipe';
    recipe?: Recipe;
    safetyNote?: string;
    conversationId?: string;
};
export async function askChef(message: string, context?: {
    recipe?: Recipe;
    session?: Session;
    conversationId?: string;
    preferences?: Preferences;
    recentJournal?: JournalEntry[];
    savedRecipes?: Recipe[];
}): Promise<ChefReply> {
    if (!message.trim() || message.length > 4000)
        throw new Error('Ask a cooking question between 1 and 4,000 characters.');
    const client = getCloudClient();
    if (!client)
        throw new Error(localModeMessage);
    const { data: account } = await client.auth.getSession();
    if (!account.session)
        throw new Error('Sign in from Kitchen settings to ask Chef. Your local recipes stay available.');
    const currentRecipe = context?.recipe ?? context?.session?.recipe;
    // Send the recipe once, and keep every quantity and instruction intact. Photos
    // and collection bookkeeping add bytes but cannot help the cooking answer.
    const recipe = currentRecipe ? {
        id: currentRecipe.id, name: currentRecipe.name, description: currentRecipe.description,
        cuisine: currentRecipe.cuisine, category: currentRecipe.category,
        ingredients: currentRecipe.ingredients, steps: currentRecipe.steps, equipment: currentRecipe.equipment,
        prepMinutes: currentRecipe.prepMinutes, cookMinutes: currentRecipe.cookMinutes,
        difficulty: currentRecipe.difficulty, servings: currentRecipe.servings,
        skills: currentRecipe.skills, notes: currentRecipe.notes,
    } : undefined;
    const body = {
        message: message.trim(), recipe, conversationId: context?.conversationId,
        session: context?.session ? { id: context.session.id, status: context.session.status, stepIndex: context.session.stepIndex } : undefined,
        localContext: {
            preferences: context?.preferences,
            recentPractice: context?.recentJournal?.slice(0, 10).map(e => ({ recipeName: e.recipeName, cuisine: e.cuisine, skills: e.skills, ratings: e.ratings, notes: e.notes.slice(0, 500), improvements: e.improvements.slice(0, 500) })) ?? [],
            savedRecipes: context?.savedRecipes?.slice(0, 20).map(r => ({ name: r.name, cuisine: r.cuisine, skills: r.skills, equipment: r.equipment })) ?? [],
        },
    };
    // Budget UTF-8 bytes, including non-Latin cuisines/ingredients. Drop the
    // oldest optional summaries first; never drop allergies or recipe steps.
    const bytes = () => encodeURIComponent(JSON.stringify(body)).replace(/%[A-F\d]{2}/g, '_').length;
    while (bytes() > 30000 && body.localContext.savedRecipes.length)
        body.localContext.savedRecipes.pop();
    while (bytes() > 30000 && body.localContext.recentPractice.length)
        body.localContext.recentPractice.pop();
    if (bytes() > 30000)
        throw new Error('This recipe and question exceed Chef’s context limit. Shorten the question or recipe notes and try again; ingredient quantities, cooking steps and allergy preferences are never silently removed.');
    const { data, error } = await client.functions.invoke('chef', { body });
    if (error) {
        let reason = 'Chef could not connect. Check your internet connection and try again. Your question has not changed any saved recipe.';
        const response = (error as {
            context?: Response;
        }).context;
        if (response && typeof response.json === 'function') {
            try {
                const detail = await response.json();
                if (typeof detail.error === 'string')
                    reason = detail.error;
            }
            catch { /* keep actionable fallback */ }
        }
        throw new Error(reason);
    }
    const parsed = replySchema.safeParse(data);
    if (!parsed.success || (parsed.data.kind === 'recipe' && !parsed.data.recipe))
        throw new Error('Chef returned an incomplete answer. Please try again; no recipe was saved.');
    return parsed.data;
}
