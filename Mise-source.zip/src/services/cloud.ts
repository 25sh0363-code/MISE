import 'react-native-url-polyfill/auto';
import { AppState } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.trim();
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY?.trim();
export const cloudConfigured = Boolean(url && anonKey);
export const localModeMessage = 'Local kitchen mode. Recipes, cooking and your journal work offline. Connect your own Supabase project to enable account sync and AI Chef.';
// SecureStore has a small per-item limit on some OS releases. Commit a new
// manifest only after all encrypted chunks exist, preserving the old session
// if an interrupted write occurs. Tokens never enter SQLite or the outbox.
const secureStorage = {
    async getItem(key: string) {
        const manifest = await SecureStore.getItemAsync(`${key}.manifest`);
        if (!manifest)
            return null;
        const { generation, count } = JSON.parse(manifest) as {
            generation: string;
            count: number;
        };
        const chunks = await Promise.all(Array.from({ length: count }, (_, i) => SecureStore.getItemAsync(`${key}.${generation}.${i}`)));
        return chunks.every(chunk => chunk !== null) ? chunks.join('') : null;
    },
    async setItem(key: string, value: string) {
        const previous = await SecureStore.getItemAsync(`${key}.manifest`);
        const generation = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        const count = Math.ceil(value.length / 500);
        for (let i = 0; i < count; i++)
            await SecureStore.setItemAsync(`${key}.${generation}.${i}`, value.slice(i * 500, (i + 1) * 500));
        await SecureStore.setItemAsync(`${key}.manifest`, JSON.stringify({ generation, count }));
        if (previous) {
            const old = JSON.parse(previous) as {
                generation: string;
                count: number;
            };
            await Promise.all(Array.from({ length: old.count }, (_, i) => SecureStore.deleteItemAsync(`${key}.${old.generation}.${i}`)));
        }
    },
    async removeItem(key: string) {
        const manifest = await SecureStore.getItemAsync(`${key}.manifest`);
        await SecureStore.deleteItemAsync(`${key}.manifest`);
        if (manifest) {
            const old = JSON.parse(manifest) as {
                generation: string;
                count: number;
            };
            await Promise.all(Array.from({ length: old.count }, (_, i) => SecureStore.deleteItemAsync(`${key}.${old.generation}.${i}`)));
        }
    },
};
let client: SupabaseClient | null = null;
export function getCloudClient(): SupabaseClient | null {
    if (!cloudConfigured)
        return null;
    if (!client) {
        client = createClient(url!, anonKey!, {
            auth: { storage: secureStorage, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
        });
        const current = client;
        AppState.addEventListener('change', state => state === 'active' ? current.auth.startAutoRefresh() : current.auth.stopAutoRefresh());
    }
    return client;
}
function requireCloud() {
    const instance = getCloudClient();
    if (!instance)
        throw new Error(localModeMessage);
    return instance;
}
export async function getAccount(): Promise<{
    id: string;
    email?: string;
} | null> {
    const instance = getCloudClient();
    if (!instance)
        return null;
    const { data, error } = await instance.auth.getSession();
    if (error)
        throw error;
    return data.session ? { id: data.session.user.id, email: data.session.user.email } : null;
}
export async function signIn(email: string, password: string) {
    const { data, error } = await requireCloud().auth.signInWithPassword({ email: email.trim(), password });
    if (error)
        throw new Error(error.message);
    return data.user;
}
export async function signUp(email: string, password: string) {
    if (password.length < 8)
        throw new Error('Choose a password with at least 8 characters.');
    const { data, error } = await requireCloud().auth.signUp({ email: email.trim(), password });
    if (error)
        throw new Error(error.message);
    return { user: data.user, confirmationRequired: !data.session };
}
export async function signOut() {
    const { error } = await requireCloud().auth.signOut();
    if (error)
        throw new Error(error.message);
}
