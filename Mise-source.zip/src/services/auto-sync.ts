import { useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import * as Network from 'expo-network';
import { useMise } from '../state/app';
import { cloudConfigured, getCloudClient } from './cloud';
import { syncNow } from './sync';
// Offline work is always committed first. Cloud failures only delay the queue;
// they never turn a local save into an error or replace an unsent local record.
export function useAutomaticSync() {
    const ready = useMise(s => s.ready);
    const pending = useMise(s => s.snapshot?.pendingSync ?? 0);
    const lastAttempt = useRef(0);
    const run = useRef<() => void>(() => undefined);
    useEffect(() => {
        if (!ready || !cloudConfigured)
            return;
        let disposed = false;
        let inFlight = false;
        async function attempt(force = false) {
            if (disposed || inFlight || (!force && Date.now() - lastAttempt.current < 30000))
                return;
            lastAttempt.current = Date.now();
            inFlight = true;
            try {
                const network = await Network.getNetworkStateAsync();
                if (network.isInternetReachable === false || !network.isConnected)
                    return;
                const account = await getCloudClient()?.auth.getSession();
                if (!account?.data.session)
                    return;
                const result = await syncNow(useMise.getState().repo);
                if (!disposed) {
                    await useMise.getState().refresh();
                    if (result.conflicts)
                        useMise.getState().notify('Both versions are safe. Review sync conflicts in Kitchen settings.');
                }
            }
            catch { /* Pending queue and conflict count remain visible in settings. */ }
            finally {
                inFlight = false;
            }
        }
        run.current = () => { void attempt(true); };
        const app = AppState.addEventListener('change', state => { if (state === 'active')
            void attempt(); });
        const network = Network.addNetworkStateListener(state => { if (state.isConnected && state.isInternetReachable !== false)
            void attempt(); });
        const auth = getCloudClient()?.auth.onAuthStateChange(event => { if (event === 'SIGNED_IN')
            setTimeout(() => { void attempt(true); }, 0); });
        const retry = setInterval(() => { if (AppState.currentState === 'active')
            void attempt(); }, 60000);
        void attempt();
        return () => { disposed = true; run.current = () => undefined; app.remove(); network.remove(); auth?.data.subscription.unsubscribe(); clearInterval(retry); };
    }, [ready]);
    useEffect(() => { if (!pending)
        return; const debounce = setTimeout(() => run.current(), 2500); return () => clearTimeout(debounce); }, [pending]);
}
