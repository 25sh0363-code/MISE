import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import type { MiseRepository } from '../db/repository';
import type { Timer } from '../domain/types';
Notifications.setNotificationHandler({
    handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }),
});
export async function scheduleTimer(timer: Timer): Promise<boolean> {
    try {
        if (Platform.OS === 'android')
            await Notifications.setNotificationChannelAsync('cooking', { name: 'Cooking timers', importance: Notifications.AndroidImportance.HIGH, sound: 'default', vibrationPattern: [0, 250, 100, 250] });
        const existing = await Notifications.getPermissionsAsync();
        const allowed = existing.granted || (existing.canAskAgain && (await Notifications.requestPermissionsAsync()).granted);
        if (!allowed || timer.endsAt <= Date.now())
            return false;
        await Notifications.scheduleNotificationAsync({
            identifier: timer.id,
            content: { title: 'Time to check your cooking', body: timer.label, sound: 'default', data: { sessionId: timer.sessionId, timerId: timer.id } },
            trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(timer.endsAt), channelId: 'cooking' },
        });
        return true;
    }
    catch {
        return false;
    }
}
export async function startTimer(repo: MiseRepository, sessionId: string, label: string, seconds: number) {
    const timer = await repo.addTimer(sessionId, label, seconds);
    const notificationScheduled = await scheduleTimer(timer);
    return { timer, notificationScheduled };
}
export async function dismissTimer(repo: MiseRepository, timerId: string) {
    await repo.cancelTimer(timerId);
    await Notifications.cancelScheduledNotificationAsync(timerId).catch(() => undefined);
    await Notifications.dismissNotificationAsync(timerId).catch(() => undefined);
}
export async function reconcileTimers(timers: Timer[]) {
    try {
        const scheduled = await Notifications.getAllScheduledNotificationsAsync();
        const valid = new Set(timers.filter(t => t.status === 'running' && t.endsAt > Date.now()).map(t => t.id));
        for (const item of scheduled)
            if (item.content.data?.timerId && !valid.has(item.identifier))
                await Notifications.cancelScheduledNotificationAsync(item.identifier);
        // Never prompt during recovery. Missing notifications are recreated only if already permitted.
        if (!(await Notifications.getPermissionsAsync()).granted)
            return;
        const existing = new Set(scheduled.map(item => item.identifier));
        for (const timer of timers)
            if (valid.has(timer.id) && !existing.has(timer.id))
                await scheduleTimer(timer);
    }
    catch { /* SQLite deadlines remain authoritative even without notification support. */ }
}
