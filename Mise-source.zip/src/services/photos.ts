import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
export async function pickCookingPhoto(camera = false): Promise<string | null> {
    const permission = camera ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted)
        throw new Error('Allow photo access in system settings to add a picture. Your journal can also be saved without one.');
    const options: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.8, allowsEditing: false };
    const result = camera ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
    if (result.canceled || !result.assets[0])
        return null;
    const asset = result.assets[0];
    const folder = `${FileSystem.documentDirectory}cooking-photos/`;
    await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
    const extension = ({ 'image/png': 'png', 'image/webp': 'webp', 'image/heic': 'heic', 'image/heif': 'heic' } as Record<string, string>)[asset.mimeType ?? ''] ?? 'jpg';
    const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${extension}`;
    const destination = folder + fileName;
    await FileSystem.copyAsync({ from: asset.uri, to: destination });
    return destination;
}
