import * as SQLite from 'expo-sqlite';
import * as Crypto from 'expo-crypto';
import { MiseRepository } from './repository';
import type { SQLiteDriver, SqlValue } from './driver';
function driver(db: SQLite.SQLiteDatabase): SQLiteDriver {
    return {
        exec: sql => db.execAsync(sql),
        run: async (sql, params = []) => { await db.runAsync(sql, params); },
        first: <T>(sql: string, params: SqlValue[] = []) => db.getFirstAsync<T>(sql, params),
        all: <T>(sql: string, params: SqlValue[] = []) => db.getAllAsync<T>(sql, params),
        transaction: async <T>(work: (tx: SQLiteDriver) => Promise<T>) => { let result!: T; await db.withExclusiveTransactionAsync(async (tx) => { result = await work(driver(tx)); }); return result; },
    };
}
let opening: Promise<MiseRepository> | undefined;
export function openRepository(): Promise<MiseRepository> {
    if (!opening)
        opening = (async () => { const db = await SQLite.openDatabaseAsync('mise.db'); const repository = new MiseRepository(driver(db), { id: () => Crypto.randomUUID() }); await repository.init(); return repository; })().catch(error => { opening = undefined; throw error; });
    return opening;
}
