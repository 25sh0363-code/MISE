export type SqlValue = string | number | null;
export interface SQLiteDriver {
    exec(sql: string): Promise<void>;
    run(sql: string, params?: SqlValue[]): Promise<void>;
    first<T>(sql: string, params?: SqlValue[]): Promise<T | null>;
    all<T>(sql: string, params?: SqlValue[]): Promise<T[]>;
    transaction<T>(work: (tx: SQLiteDriver) => Promise<T>): Promise<T>;
}
