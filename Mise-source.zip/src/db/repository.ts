import type { SQLiteDriver } from './driver.ts';
import { migrate } from './migrations.ts';
import { awardChallenges, CHALLENGES, challengePeriod } from '../domain/challenges.ts';
import { STARTER_RECIPES } from '../data/recipes.ts';
import { DEFAULT_PREFERENCES, elapsedSeconds, xpForPractice } from '../domain/progression.ts';
import type { AppSnapshot, Conflict, JournalEntry, OutboxItem, Preferences, Recipe, RecipeRecord, Review, Session, SyncEntity, Timer } from '../domain/types.ts';
type JsonRow = {
    payload: string;
};
type OutboxRow = {
    id: string;
    entity: SyncEntity;
    entity_id: string;
    operation: 'upsert' | 'delete';
    payload: string;
    base_revision: number;
    created_at: number;
    attempts: number;
    owner_id?: string;
};
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
export class MiseRepository {
    private now: () => number;
    private id: () => string;
    private queue: Promise<unknown> = Promise.resolve();
    private db: SQLiteDriver;
    constructor(db: SQLiteDriver, options: {
        now?: () => number;
        id?: () => string;
    } = {}) {
        this.db = db;
        this.now = options.now ?? Date.now;
        this.id = options.id ?? (() => globalThis.crypto.randomUUID());
    }
    private write<T>(work: (tx: SQLiteDriver) => Promise<T>): Promise<T> {
        const next = this.queue.then(() => this.db.transaction(work));
        this.queue = next.catch(() => undefined);
        return next;
    }
    async init() {
        await migrate(this.db);
        await this.write(async (tx) => {
            for (const recipe of STARTER_RECIPES) {
                const existing = await tx.first('SELECT id FROM recipes WHERE id = ?', [recipe.id]);
                if (!existing) {
                    const record: RecipeRecord = { recipe, saved: false, favorite: false, archived: false, revision: 1 };
                    await tx.run('INSERT INTO recipes(id,payload,saved,favorite,archived,local_revision,updated_at) VALUES(?,?,0,0,0,1,?)', [recipe.id, JSON.stringify(record), this.now()]);
                }
            }
            await tx.run("INSERT OR IGNORE INTO metadata(key,value) VALUES('preferences',?)", [JSON.stringify(DEFAULT_PREFERENCES)]);
        });
    }
    async snapshot(): Promise<AppSnapshot> {
        await this.queue;
        const [recipes, sessions, timers, journal, prefs, pending, conflicts] = await Promise.all([
            this.db.all<JsonRow>('SELECT payload FROM recipes ORDER BY rowid'), this.db.all<JsonRow>('SELECT payload FROM sessions ORDER BY updated_at DESC'), this.db.all<JsonRow>('SELECT payload FROM timers ORDER BY ends_at'), this.db.all<JsonRow>('SELECT payload FROM journal ORDER BY completed_at DESC'), this.db.first<{
                value: string;
            }>("SELECT value FROM metadata WHERE key='preferences'"), this.db.first<{
                count: number;
            }>("SELECT count(*) AS count FROM outbox WHERE status='pending'"), this.db.first<{
                count: number;
            }>('SELECT count(*) AS count FROM conflicts'),
        ]);
        return { recipes: recipes.map(r => JSON.parse(r.payload)), sessions: sessions.map(r => JSON.parse(r.payload)), timers: timers.map(r => JSON.parse(r.payload)), journal: journal.map(r => JSON.parse(r.payload)), preferences: prefs ? { ...DEFAULT_PREFERENCES, ...JSON.parse(prefs.value) } : clone(DEFAULT_PREFERENCES), pendingSync: pending?.count ?? 0, conflicts: conflicts?.count ?? 0 };
    }
    private async enqueue(tx: SQLiteDriver, entity: SyncEntity, entityId: string, payload: unknown, operation: 'upsert' | 'delete' = 'upsert') {
        const revision = await tx.first<{
            revision: number;
        }>('SELECT revision FROM sync_revisions WHERE entity=? AND entity_id=?', [entity, entityId]);
        const owner = await tx.first<{
            value: string;
        }>("SELECT value FROM metadata WHERE key='sync_owner'");
        await tx.run('INSERT INTO outbox(id,entity,entity_id,operation,payload,base_revision,created_at,owner_id) VALUES(?,?,?,?,?,?,?,?)', [this.id(), entity, entityId, operation, JSON.stringify(payload), revision?.revision ?? 0, this.now(), owner?.value ?? null]);
    }
    private async recipe(tx: SQLiteDriver, id: string): Promise<RecipeRecord> {
        const row = await tx.first<JsonRow>('SELECT payload FROM recipes WHERE id=?', [id]);
        if (!row)
            throw new Error('This recipe is no longer in your kitchen.');
        return JSON.parse(row.payload);
    }
    private async persistRecipe(tx: SQLiteDriver, record: RecipeRecord) {
        await tx.run('INSERT INTO recipes(id,payload,saved,favorite,archived,local_revision,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved=excluded.saved,favorite=excluded.favorite,archived=excluded.archived,local_revision=excluded.local_revision,updated_at=excluded.updated_at', [record.recipe.id, JSON.stringify(record), +record.saved, +record.favorite, +record.archived, record.revision, this.now()]);
    }
    async saveRecipe(id: string) { return this.write(async (tx) => { const record = await this.recipe(tx, id); if (record.saved && !record.archived)
        return record; record.saved = true; record.archived = false; record.revision++; await this.persistRecipe(tx, record); await this.enqueue(tx, 'recipes', id, record); return record; }); }
    async putRecipe(recipe: Recipe) { return this.write(async (tx) => { validateRecipe(recipe); const existing = await tx.first<JsonRow>('SELECT payload FROM recipes WHERE id=?', [recipe.id]); const prior: RecipeRecord | undefined = existing && JSON.parse(existing.payload); const record: RecipeRecord = { recipe: clone(recipe), saved: true, favorite: prior?.favorite ?? false, archived: false, revision: (prior?.revision ?? 0) + 1 }; await this.persistRecipe(tx, record); await this.enqueue(tx, 'recipes', recipe.id, record); if (recipe.imageUri?.startsWith('file:'))
        await tx.run('INSERT OR IGNORE INTO photos(id,local_uri,entity_id,created_at) VALUES(?,?,?,?)', [this.id(), recipe.imageUri, recipe.id, this.now()]); return record; }); }
    async toggleFavorite(id: string) { return this.write(async (tx) => { const record = await this.recipe(tx, id); record.favorite = !record.favorite; record.saved = true; record.archived = false; record.revision++; await this.persistRecipe(tx, record); await this.enqueue(tx, 'recipes', id, record); return record; }); }
    async archiveRecipe(id: string) { return this.write(async (tx) => { const record = await this.recipe(tx, id); record.archived = !record.archived; record.revision++; await this.persistRecipe(tx, record); await this.enqueue(tx, 'recipes', id, record); return record; }); }
    async deleteRecipe(id: string) { return this.write(async (tx) => { const record = await this.recipe(tx, id); if (record.recipe.source === 'starter') {
        record.saved = false;
        record.favorite = false;
        record.archived = false;
        record.revision++;
        await this.persistRecipe(tx, record);
    }
    else
        await tx.run('DELETE FROM recipes WHERE id=?', [id]); await this.enqueue(tx, 'recipes', id, { id }, 'delete'); }); }
    private async session(tx: SQLiteDriver, id: string): Promise<Session> { const row = await tx.first<JsonRow>('SELECT payload FROM sessions WHERE id=?', [id]); if (!row)
        throw new Error('This cooking session could not be found.'); return JSON.parse(row.payload); }
    private async persistSession(tx: SQLiteDriver, session: Session) { await tx.run('INSERT INTO sessions(id,recipe_id,status,payload,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,payload=excluded.payload,updated_at=excluded.updated_at', [session.id, session.recipe.id, session.status, JSON.stringify(session), this.now()]); await this.enqueue(tx, 'cooking_sessions', session.id, session); }
    async startSession(recipeId: string) { return this.write(async (tx) => { const active = await tx.first<JsonRow>("SELECT payload FROM sessions WHERE status IN ('preparing','cooking','paused','reviewing')"); if (active) {
        const session: Session = JSON.parse(active.payload);
        if (session.recipe.id === recipeId)
            return session;
        throw new Error(`Your ${session.recipe.name} session is still open. Finish that session before starting another.`);
    } const record = await this.recipe(tx, recipeId); const snapshotRecipe = clone(record.recipe); const session: Session = { id: this.id(), recipe: snapshotRecipe, status: 'preparing', stepIndex: 0, checkedIngredients: [], checkedEquipment: [], startedAt: this.now(), pausedMs: 0 }; await this.persistSession(tx, session); return session; }); }
    async updateSession(id: string, patch: Partial<Session>) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status === 'reviewing' && patch.reviewDraft) {
        session.reviewDraft = { ...session.reviewDraft, ...clone(patch.reviewDraft) };
        await this.persistSession(tx, session);
        return session;
    } if (session.status !== 'preparing')
        throw new Error('Checklists can only be changed during preparation.'); if (patch.checkedIngredients)
        session.checkedIngredients = [...new Set(patch.checkedIngredients)].filter(v => session.recipe.ingredients.some(i => i.id === v)); if (patch.checkedEquipment)
        session.checkedEquipment = [...new Set(patch.checkedEquipment)].filter(v => session.recipe.equipment.includes(v)); await this.persistSession(tx, session); return session; }); }
    async beginCooking(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status !== 'preparing')
        return session; if (session.checkedIngredients.length !== session.recipe.ingredients.length || session.checkedEquipment.length !== session.recipe.equipment.length)
        throw new Error('Check your ingredients and equipment before cooking.'); session.status = 'cooking'; session.cookingStartedAt = this.now(); await this.persistSession(tx, session); return session; }); }
    async pauseSession(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status === 'cooking') {
        session.status = 'paused';
        session.pausedAt = this.now();
        await this.persistSession(tx, session);
    } return session; }); }
    async resumeSession(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status === 'paused') {
        session.pausedMs += Math.max(0, this.now() - (session.pausedAt ?? this.now()));
        session.pausedAt = undefined;
        session.status = 'cooking';
        await this.persistSession(tx, session);
    } return session; }); }
    async nextStep(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status !== 'cooking')
        throw new Error('Resume cooking before continuing.'); session.stepIndex = Math.min(session.recipe.steps.length - 1, session.stepIndex + 1); await this.persistSession(tx, session); return session; }); }
    async previousStep(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (!['cooking', 'paused'].includes(session.status))
        return session; session.stepIndex = Math.max(0, session.stepIndex - 1); await this.persistSession(tx, session); return session; }); }
    async finishCooking(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status === 'reviewing' || session.status === 'completed')
        return session; if (session.status !== 'cooking' || session.stepIndex !== session.recipe.steps.length - 1)
        throw new Error('Follow the remaining steps before finishing your recipe.'); session.status = 'reviewing'; session.finishedAt = this.now(); await this.persistSession(tx, session); return session; }); }
    async completeSession(id: string, review: Review): Promise<JournalEntry> {
        return this.write(async (tx) => {
            const previous = await tx.first<JsonRow>('SELECT payload FROM journal WHERE session_id=?', [id]);
            if (previous)
                return JSON.parse(previous.payload);
            validateReview(review);
            const session = await this.session(tx, id);
            if (session.status !== 'reviewing' || session.finishedAt === undefined)
                throw new Error('Finish cooking before saving your review.');
            const history = await tx.first<{
                count: number;
            }>('SELECT count(*) AS count FROM journal WHERE recipe_id=?', [session.recipe.id]);
            const entry: JournalEntry = { ...clone(review), id: this.id(), sessionId: id, recipeId: session.recipe.id, recipeName: session.recipe.name, cuisine: session.recipe.cuisine, skills: [...session.recipe.skills], recipeCategory: session.recipe.category, durationSeconds: elapsedSeconds(session, this.now()), completedAt: session.finishedAt, xp: xpForPractice(session.recipe.difficulty, !history?.count) };
            const prefRow = await tx.first<{
                value: string;
            }>("SELECT value FROM metadata WHERE key='preferences'");
            const preferences: Preferences = { ...DEFAULT_PREFERENCES, ...(prefRow ? JSON.parse(prefRow.value) : {}) };
            const historyRows = await tx.all<JsonRow>('SELECT payload FROM journal');
            const challengeAward = awardChallenges([...historyRows.map(r => JSON.parse(r.payload)), entry], preferences, entry.completedAt);
            if (challengeAward.bonus) {
                entry.challengeXP = challengeAward.bonus;
                entry.xp += challengeAward.bonus;
                preferences.challengeEnrollments = challengeAward.enrollments;
                await tx.run("UPDATE metadata SET value=? WHERE key='preferences'", [JSON.stringify(preferences)]);
                await this.enqueue(tx, 'preferences', 'preferences', preferences);
            }
            await tx.run('INSERT INTO journal(id,session_id,recipe_id,completed_at,payload) VALUES(?,?,?,?,?)', [entry.id, id, entry.recipeId, entry.completedAt, JSON.stringify(entry)]);
            const timers = await tx.all<JsonRow>("SELECT payload FROM timers WHERE session_id=? AND status='running'", [id]);
            for (const row of timers) {
                const timer: Timer = JSON.parse(row.payload);
                timer.status = 'cancelled';
                await tx.run("UPDATE timers SET status='cancelled',payload=? WHERE id=?", [JSON.stringify(timer), timer.id]);
            }
            session.status = 'completed';
            await this.persistSession(tx, session);
            await this.enqueue(tx, 'journal_entries', entry.id, entry);
            for (const uri of entry.photos)
                await tx.run('INSERT OR IGNORE INTO photos(id,local_uri,entity_id,created_at) VALUES(?,?,?,?)', [this.id(), uri, entry.id, this.now()]);
            return entry;
        });
    }
    async addTimer(sessionId: string, label: string, seconds: number) { return this.write(async (tx) => { const session = await this.session(tx, sessionId); if (!['preparing', 'cooking', 'paused'].includes(session.status))
        throw new Error('Timers can only be added to an active cooking session.'); if (!Number.isFinite(seconds) || seconds < 1 || seconds > 86400)
        throw new Error('Choose a timer between 1 second and 24 hours.'); const timer: Timer = { id: this.id(), sessionId, label: label.trim().slice(0, 120) || 'Cooking timer', endsAt: this.now() + Math.round(seconds * 1000), status: 'running' }; await tx.run('INSERT INTO timers(id,session_id,status,ends_at,payload) VALUES(?,?,?,?,?)', [timer.id, sessionId, timer.status, timer.endsAt, JSON.stringify(timer)]); return timer; }); }
    async setTimerNotification(id: string, notificationId: string) { return this.write(async (tx) => { const row = await tx.first<JsonRow>('SELECT payload FROM timers WHERE id=?', [id]); if (!row)
        return; const timer: Timer = JSON.parse(row.payload); timer.notificationId = notificationId; await tx.run('UPDATE timers SET payload=? WHERE id=?', [JSON.stringify(timer), id]); }); }
    async cancelTimer(id: string) { return this.write(async (tx) => { const row = await tx.first<JsonRow>('SELECT payload FROM timers WHERE id=?', [id]); if (!row)
        return; const timer: Timer = JSON.parse(row.payload); timer.status = 'cancelled'; await tx.run("UPDATE timers SET status='cancelled',payload=? WHERE id=?", [JSON.stringify(timer), id]); return timer; }); }
    async updatePreferences(patch: Partial<Preferences>) { return this.write(async (tx) => { const row = await tx.first<{
        value: string;
    }>("SELECT value FROM metadata WHERE key='preferences'"); const preferences: Preferences = { ...DEFAULT_PREFERENCES, ...(row ? JSON.parse(row.value) : {}), ...clone(patch) }; if (!['system', 'light', 'dark'].includes(preferences.theme))
        throw new Error('Choose a valid appearance.'); await tx.run("INSERT OR REPLACE INTO metadata(key,value) VALUES('preferences',?)", [JSON.stringify(preferences)]); await this.enqueue(tx, 'preferences', 'preferences', preferences); return preferences; }); }
    async abandonSession(id: string) { return this.write(async (tx) => { const session = await this.session(tx, id); if (session.status === 'completed' || session.status === 'abandoned')
        return session; if (session.status === 'paused')
        session.pausedMs += Math.max(0, this.now() - (session.pausedAt ?? this.now())); session.status = 'abandoned'; session.finishedAt = this.now(); session.pausedAt = undefined; const rows = await tx.all<JsonRow>("SELECT payload FROM timers WHERE session_id=? AND status='running'", [id]); for (const row of rows) {
        const timer: Timer = JSON.parse(row.payload);
        timer.status = 'cancelled';
        await tx.run("UPDATE timers SET status='cancelled',payload=? WHERE id=?", [JSON.stringify(timer), timer.id]);
    } await this.persistSession(tx, session); return session; }); }
    async enrollChallenge(id: string) { return this.write(async (tx) => { const challenge = CHALLENGES.find(c => c.id === id); if (!challenge)
        throw new Error('This cooking challenge could not be found.'); const row = await tx.first<{
        value: string;
    }>("SELECT value FROM metadata WHERE key='preferences'"); const preferences: Preferences = { ...DEFAULT_PREFERENCES, ...(row ? JSON.parse(row.value) : {}) }; const key = challengePeriod(challenge.period, this.now()); const enrollments = preferences.challengeEnrollments ?? []; if (!enrollments.some(e => e.id === id && e.periodKey === key))
        enrollments.push({ id, periodKey: key, enrolledAt: this.now(), xpAwarded: 0 }); preferences.challengeEnrollments = enrollments; await tx.run("UPDATE metadata SET value=? WHERE key='preferences'", [JSON.stringify(preferences)]); await this.enqueue(tx, 'preferences', 'preferences', preferences); return preferences; }); }
    async joinChallenge(id: string) { return this.enrollChallenge(id); }
    async resolveConflict(id: string, choice: 'local' | 'remote' | 'keep-local' | 'use-remote') {
        return this.write(async (tx) => {
            const row = await tx.first<{
                id: string;
                entity: SyncEntity;
                entity_id: string;
                local_payload: string;
                remote_payload: string;
            }>('SELECT * FROM conflicts WHERE id=?', [id]);
            if (!row)
                return;
            const incoming = JSON.parse(row.remote_payload);
            const envelope = incoming && typeof incoming === 'object' && 'payload' in incoming ? incoming : { payload: incoming, revision: 0, deleted: false };
            let current = row.local_payload;
            if (row.entity === 'recipes') {
                const local = await tx.first<JsonRow>('SELECT payload FROM recipes WHERE id=?', [row.entity_id]);
                if (local)
                    current = local.payload;
            }
            if (row.entity === 'cooking_sessions') {
                const local = await tx.first<JsonRow>('SELECT payload FROM sessions WHERE id=?', [row.entity_id]);
                if (local)
                    current = local.payload;
            }
            if (row.entity === 'journal_entries') {
                const local = await tx.first<JsonRow>('SELECT payload FROM journal WHERE id=?', [row.entity_id]);
                if (local)
                    current = local.payload;
            }
            if (row.entity === 'preferences') {
                const local = await tx.first<{
                    value: string;
                }>("SELECT value FROM metadata WHERE key='preferences'");
                if (local)
                    current = local.value;
            }
            const latest = await tx.first<{
                operation: 'upsert' | 'delete';
            }>('SELECT operation FROM outbox WHERE entity=? AND entity_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1', [row.entity, row.entity_id]);
            await tx.run('INSERT OR REPLACE INTO conflict_history(id,entity,entity_id,local_payload,remote_payload,resolution,resolved_at) VALUES(?,?,?,?,?,?,?)', [id, row.entity, row.entity_id, current, row.remote_payload, choice, this.now()]);
            await tx.run('DELETE FROM outbox WHERE entity=? AND entity_id=?', [row.entity, row.entity_id]);
            await tx.run('DELETE FROM conflicts WHERE entity=? AND entity_id=?', [row.entity, row.entity_id]);
            await tx.run('INSERT OR REPLACE INTO sync_revisions(entity,entity_id,revision) VALUES(?,?,?)', [row.entity, row.entity_id, envelope.revision ?? 0]);
            if (choice === 'remote' || choice === 'use-remote')
                await this.applyRemote(tx, row.entity, row.entity_id, JSON.stringify(envelope.payload), !!envelope.deleted);
            else
                await this.enqueue(tx, row.entity, row.entity_id, JSON.parse(current), latest?.operation ?? 'upsert');
        });
    }
    async getPendingMutations(): Promise<OutboxItem[]> { const rows = await this.db.all<OutboxRow>("SELECT * FROM outbox WHERE status='pending' ORDER BY created_at,rowid LIMIT 100"); return rows.map(r => ({ id: r.id, entity: r.entity, entityId: r.entity_id, operation: r.operation, payload: r.payload, baseRevision: r.base_revision, createdAt: r.created_at, attempts: r.attempts, ownerId: r.owner_id })); }
    async ackMutation(id: string, revision: number) { return this.write(async (tx) => { const row = await tx.first<OutboxRow>('SELECT * FROM outbox WHERE id=?', [id]); if (!row)
        return; await tx.run('INSERT INTO sync_revisions(entity,entity_id,revision) VALUES(?,?,?) ON CONFLICT(entity,entity_id) DO UPDATE SET revision=MAX(revision,excluded.revision)', [row.entity, row.entity_id, revision]); await tx.run('DELETE FROM outbox WHERE id=?', [id]); await tx.run("UPDATE outbox SET base_revision=? WHERE entity=? AND entity_id=? AND status='pending'", [revision, row.entity, row.entity_id]); }); }
    async markConflict(id: string, remotePayload: string) { return this.write(async (tx) => { const row = await tx.first<OutboxRow>('SELECT * FROM outbox WHERE id=?', [id]); if (!row)
        return; JSON.parse(remotePayload); await tx.run("UPDATE outbox SET status='conflict' WHERE entity=? AND entity_id=?", [row.entity, row.entity_id]); await tx.run('INSERT OR REPLACE INTO conflicts(id,entity,entity_id,local_payload,remote_payload,created_at) VALUES(?,?,?,?,?,?)', [id, row.entity, row.entity_id, row.payload, remotePayload, this.now()]); }); }
    async listConflicts(): Promise<Conflict[]> { const rows = await this.db.all<{
        id: string;
        entity: SyncEntity;
        entity_id: string;
        local_payload: string;
        remote_payload: string;
        created_at: number;
    }>('SELECT * FROM conflicts ORDER BY created_at'); return rows.map(r => ({ id: r.id, entity: r.entity, entityId: r.entity_id, localPayload: r.local_payload, remotePayload: r.remote_payload, createdAt: r.created_at })); }
    async mergeRemote(entity: SyncEntity, id: string, payload: string, revision: number, deleted = false) { return this.write(async (tx) => { const pending = await tx.first('SELECT id FROM outbox WHERE entity=? AND entity_id=?', [entity, id]); if (pending)
        return false; const known = await tx.first<{
        revision: number;
    }>('SELECT revision FROM sync_revisions WHERE entity=? AND entity_id=?', [entity, id]); if (known && known.revision >= revision)
        return false; await this.applyRemote(tx, entity, id, payload, deleted); await tx.run('INSERT OR REPLACE INTO sync_revisions(entity,entity_id,revision) VALUES(?,?,?)', [entity, id, revision]); return true; }); }
    private async applyRemote(tx: SQLiteDriver, entity: SyncEntity, id: string, payload: string, deleted: boolean) {
        if (entity === 'recipes') {
            if (deleted) {
                const row = await tx.first<JsonRow>('SELECT payload FROM recipes WHERE id=?', [id]);
                if (row) {
                    const record: RecipeRecord = JSON.parse(row.payload);
                    if (record.recipe.source === 'starter') {
                        record.saved = false;
                        record.favorite = false;
                        await this.persistRecipe(tx, record);
                    }
                    else
                        await tx.run('DELETE FROM recipes WHERE id=?', [id]);
                }
            }
            else {
                const record: RecipeRecord = JSON.parse(payload);
                validateRecipe(record.recipe);
                if (record.recipe.id !== id)
                    throw new Error('Invalid synchronized recipe ID.');
                await this.persistRecipe(tx, record);
            }
        }
        if (entity === 'preferences' && !deleted) {
            const prefs = JSON.parse(payload);
            await tx.run("INSERT OR REPLACE INTO metadata(key,value) VALUES('preferences',?)", [JSON.stringify({ ...DEFAULT_PREFERENCES, ...prefs })]);
        }
        if (entity === 'cooking_sessions' && !deleted) {
            const session: Session = JSON.parse(payload);
            if (session.id !== id)
                throw new Error('Invalid synchronized session ID.');
            const active = await tx.first<{
                id: string;
            }>("SELECT id FROM sessions WHERE status IN ('preparing','cooking','paused','reviewing') AND id!=?", [id]);
            if (active && ['preparing', 'cooking', 'paused', 'reviewing'].includes(session.status))
                throw new Error('Another device has an open cooking session. Complete your local session before syncing it.');
            await tx.run('INSERT INTO sessions(id,recipe_id,status,payload,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,payload=excluded.payload,updated_at=excluded.updated_at', [id, session.recipe.id, session.status, payload, this.now()]);
        }
        if (entity === 'journal_entries' && !deleted) {
            const entry: JournalEntry = JSON.parse(payload);
            validateReview(entry);
            if (entry.id !== id)
                throw new Error('Invalid synchronized journal ID.');
            const session = await tx.first('SELECT id FROM sessions WHERE id=?', [entry.sessionId]);
            if (!session)
                throw new Error('Sync cooking sessions before their journal entries.');
            await tx.run('INSERT INTO journal(id,session_id,recipe_id,completed_at,payload) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,completed_at=excluded.completed_at', [id, entry.sessionId, entry.recipeId, entry.completedAt, payload]);
        }
    }
    async bindSyncOwner(userId: string) { return this.write(async (tx) => { const row = await tx.first<{
        value: string;
    }>("SELECT value FROM metadata WHERE key='sync_owner'"); if (row && row.value !== userId)
        throw new Error('This local kitchen belongs to a different account. Sign in to that account to protect its private data.'); await tx.run("INSERT OR IGNORE INTO metadata(key,value) VALUES('sync_owner',?)", [userId]); await tx.run('UPDATE outbox SET owner_id=? WHERE owner_id IS NULL', [userId]); await tx.run('UPDATE photos SET owner_id=? WHERE owner_id IS NULL', [userId]); }); }
    async getPendingPhotos(): Promise<{
        id: string;
        localUri: string;
        entityId: string;
        ownerId?: string;
    }[]> { const rows = await this.db.all<{
        id: string;
        local_uri: string;
        entity_id: string;
        owner_id?: string;
    }>('SELECT id,local_uri,entity_id,owner_id FROM photos WHERE remote_path IS NULL ORDER BY created_at'); return rows.map(r => ({ id: r.id, localUri: r.local_uri, entityId: r.entity_id, ownerId: r.owner_id })); }
    async registerDownloadedPhoto(localUri: string, remotePath: string, entityId: string): Promise<void> {
        return this.write(async (tx) => {
            const owner = await tx.first<{
                value: string;
            }>("SELECT value FROM metadata WHERE key='sync_owner'");
            if (!owner || !remotePath.startsWith(`${owner.value}/`) || remotePath.includes('..'))
                throw new Error('This cloud photograph does not belong to the local account.');
            const existing = await tx.first<{
                owner_id?: string;
                remote_path?: string;
            }>('SELECT owner_id,remote_path FROM photos WHERE local_uri=?', [localUri]);
            if (existing?.owner_id && existing.owner_id !== owner.value)
                throw new Error('This local photograph belongs to another account.');
            if (existing?.remote_path && existing.remote_path !== remotePath)
                throw new Error('A cloud photograph mapping changed unexpectedly. The local original was retained.');
            await tx.run('INSERT INTO photos(id,local_uri,entity_id,remote_path,owner_id,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(local_uri) DO UPDATE SET remote_path=excluded.remote_path,owner_id=excluded.owner_id', [this.id(), localUri, entityId, remotePath, owner.value, this.now()]);
        });
    }
    async getPhotos(): Promise<{
        id: string;
        localUri: string;
        entityId: string;
        ownerId?: string;
        remotePath?: string;
    }[]> { const rows = await this.db.all<{
        id: string;
        local_uri: string;
        entity_id: string;
        owner_id?: string;
        remote_path?: string;
    }>('SELECT * FROM photos ORDER BY created_at'); return rows.map(r => ({ id: r.id, localUri: r.local_uri, entityId: r.entity_id, ownerId: r.owner_id, remotePath: r.remote_path })); }
    async ackPhoto(id: string, remotePath: string) { return this.write(tx => tx.run('UPDATE photos SET remote_path=? WHERE id=?', [remotePath, id])); }
}
export function validateRecipe(recipe: Recipe) {
    if (!recipe.id?.trim() || !recipe.name?.trim() || !recipe.description?.trim())
        throw new Error('Give your recipe a name and description.');
    if (!Array.isArray(recipe.ingredients) || !recipe.ingredients.length || recipe.ingredients.some(i => !i.id || !i.name?.trim() || !Number.isFinite(i.quantity) || i.quantity <= 0))
        throw new Error('Add ingredients with positive quantities.');
    if (!Array.isArray(recipe.steps) || !recipe.steps.length || recipe.steps.some(s => !s.id || !s.title?.trim() || !s.instruction?.trim()))
        throw new Error('Add a title and instruction for each cooking step.');
    if (new Set(recipe.ingredients.map(i => i.id)).size !== recipe.ingredients.length || new Set(recipe.steps.map(s => s.id)).size !== recipe.steps.length)
        throw new Error('Ingredient and step identifiers must be unique.');
    if (!Number.isInteger(recipe.servings) || recipe.servings < 1 || !Number.isInteger(recipe.difficulty) || recipe.difficulty < 1 || recipe.difficulty > 5)
        throw new Error('Choose at least one serving and difficulty 1–5.');
    if (![recipe.prepMinutes, recipe.cookMinutes].every(n => Number.isFinite(n) && n >= 0))
        throw new Error('Recipe times cannot be negative.');
}
export function validateReview(review: Review) { for (const value of Object.values(review.ratings ?? {}))
    if (!Number.isInteger(value) || value < 1 || value > 5)
        throw new Error('Rate each part of your dish from 1 to 5.'); if (!review.ratings || ['taste', 'texture', 'presentation', 'overall'].some(k => !Number.isInteger(review.ratings[k as keyof Review['ratings']])))
    throw new Error('Add all four dish ratings before saving.'); if (!Array.isArray(review.photos) || typeof review.notes !== 'string' || typeof review.improvements !== 'string')
    throw new Error('The review could not be saved. Check its notes and photographs.'); }
