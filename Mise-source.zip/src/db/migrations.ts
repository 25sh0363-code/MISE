import type { SQLiteDriver } from './driver.ts';
export const DATABASE_VERSION = 2;
export async function migrate(db: SQLiteDriver) {
    await db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
    const version = await db.first<{
        user_version: number;
    }>('PRAGMA user_version');
    if ((version?.user_version ?? 0) > DATABASE_VERSION)
        throw new Error('This library was created by a newer version of Mise. Update the app to open it safely.');
    if ((version?.user_version ?? 0) === 0) {
        await db.transaction(async (tx) => {
            await tx.exec(`
        CREATE TABLE IF NOT EXISTS recipes (id TEXT PRIMARY KEY, payload TEXT NOT NULL CHECK(json_valid(payload)), saved INTEGER NOT NULL DEFAULT 0 CHECK(saved IN (0,1)), favorite INTEGER NOT NULL DEFAULT 0 CHECK(favorite IN (0,1)), archived INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0,1)), local_revision INTEGER NOT NULL DEFAULT 1, updated_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, recipe_id TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('preparing','cooking','paused','reviewing','completed')), payload TEXT NOT NULL CHECK(json_valid(payload)), updated_at INTEGER NOT NULL);
        CREATE UNIQUE INDEX IF NOT EXISTS one_active_session ON sessions((1)) WHERE status != 'completed';
        CREATE TABLE IF NOT EXISTS journal (id TEXT PRIMARY KEY, session_id TEXT NOT NULL UNIQUE REFERENCES sessions(id), recipe_id TEXT NOT NULL, completed_at INTEGER NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)));
        CREATE INDEX IF NOT EXISTS journal_recipe_date ON journal(recipe_id,completed_at DESC);
        CREATE TABLE IF NOT EXISTS timers (id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES sessions(id), status TEXT NOT NULL CHECK(status IN ('running','cancelled')), ends_at INTEGER NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)));
        CREATE INDEX IF NOT EXISTS timer_active ON timers(status,ends_at);
        CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS outbox (id TEXT PRIMARY KEY, entity TEXT NOT NULL, entity_id TEXT NOT NULL, operation TEXT NOT NULL CHECK(operation IN ('upsert','delete')), payload TEXT NOT NULL CHECK(json_valid(payload)), base_revision INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','conflict')), owner_id TEXT);
        CREATE INDEX IF NOT EXISTS outbox_order ON outbox(status,created_at);
        CREATE TABLE IF NOT EXISTS sync_revisions (entity TEXT NOT NULL, entity_id TEXT NOT NULL, revision INTEGER NOT NULL, PRIMARY KEY(entity,entity_id));
        CREATE TABLE IF NOT EXISTS conflicts (id TEXT PRIMARY KEY, entity TEXT NOT NULL, entity_id TEXT NOT NULL, local_payload TEXT NOT NULL, remote_payload TEXT NOT NULL, created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS photos (id TEXT PRIMARY KEY, local_uri TEXT NOT NULL UNIQUE, entity_id TEXT NOT NULL, remote_path TEXT, owner_id TEXT, created_at INTEGER NOT NULL);
        PRAGMA user_version = 1;
      `);
        });
    }
    if ((version?.user_version ?? 0) < 2) {
        // Foreign keys are disabled only for the transactional table replacement;
        // journal and timer relationships still reference the stable sessions name.
        await db.exec('PRAGMA foreign_keys = OFF;');
        try {
            await db.transaction(async (tx) => {
                await tx.exec(`
          CREATE TABLE sessions_v2 (id TEXT PRIMARY KEY, recipe_id TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('preparing','cooking','paused','reviewing','completed','abandoned')), payload TEXT NOT NULL CHECK(json_valid(payload)), updated_at INTEGER NOT NULL);
          INSERT INTO sessions_v2 SELECT * FROM sessions;
          DROP TABLE sessions;
          ALTER TABLE sessions_v2 RENAME TO sessions;
          CREATE UNIQUE INDEX one_active_session ON sessions((1)) WHERE status IN ('preparing','cooking','paused','reviewing');
          CREATE TABLE IF NOT EXISTS conflict_history (id TEXT PRIMARY KEY, entity TEXT NOT NULL, entity_id TEXT NOT NULL, local_payload TEXT NOT NULL, remote_payload TEXT NOT NULL, resolution TEXT NOT NULL, resolved_at INTEGER NOT NULL);
          PRAGMA user_version = 2;
        `);
            });
        }
        finally {
            await db.exec('PRAGMA foreign_keys = ON;');
        }
        const invalid = await db.all('PRAGMA foreign_key_check');
        if (invalid.length)
            throw new Error('Mise found an inconsistent database relationship. Your data has been retained for recovery.');
    }
}
