import { useColorScheme } from 'react-native';
import { useMise } from './state/app';
export const light = { bg: '#F8F5EF', cream: '#EFE8DA', background: '#F8F5EF', surface: '#EFE8DA', paper: '#FFFDF8', text: '#29251F', muted: '#6D6A5E', primary: '#344E41', onPrimary: '#FFFFFF', sage: '#A3B18A', accent: '#A45334', gold: '#8D6627', border: '#D8D3C6', danger: '#AC3831' };
export const dark = { bg: '#1D241F', cream: '#2C362D', background: '#1D241F', surface: '#2C362D', paper: '#253029', text: '#F8F5EF', muted: '#C0C5B8', primary: '#A3B18A', onPrimary: '#1D241F', sage: '#A3B18A', accent: '#E8A286', gold: '#D4A65A', border: '#465345', danger: '#FFA59E' };
export function useTheme() { const scheme = useColorScheme(); const preference = useMise(s => s.snapshot?.preferences.theme ?? 'system'); const isDark = preference === 'dark' || (preference === 'system' && scheme === 'dark'); return { colors: isDark ? dark : light, dark: isDark }; }
