import type { JournalEntry, Session } from './types.ts';
export const SKILLS = ['Knife Skills', 'Heat Control', 'Seasoning', 'Sauces', 'Baking', 'Dough Handling', 'Food Preparation', 'Presentation', 'Timing', 'Culinary Creativity'];
export const DEFAULT_PREFERENCES = { experience: 'Finding my feet', cuisines: [] as string[], dietary: [] as string[], allergies: '', equipment: ['Frying pan', 'Saucepan', 'Oven', 'Knife'] as string[], goals: [] as string[], onboarded: false, theme: 'system' as const };
export function elapsedSeconds(session: Session, now = Date.now()): number {
    const end = session.finishedAt ?? (session.status === 'paused' ? session.pausedAt ?? now : now);
    return Math.max(0, Math.floor((end - session.startedAt - session.pausedMs) / 1000));
}
export function timerRemaining(endsAt: number, now = Date.now()): number { return Math.max(0, Math.ceil((endsAt - now) / 1000)); }
export function formatDuration(seconds: number): string {
    const safe = Math.max(0, Math.floor(seconds));
    return safe >= 3600 ? `${Math.floor(safe / 3600)}:${String(Math.floor(safe / 60) % 60).padStart(2, '0')}:${String(safe % 60).padStart(2, '0')}` : `${Math.floor(safe / 60)}:${String(safe % 60).padStart(2, '0')}`;
}
export function xpForPractice(difficulty: number, firstAttempt: boolean): number { return 60 + Math.max(1, Math.min(5, difficulty)) * 20 + (firstAttempt ? 30 : 0); }
export function chefProgress(journal: JournalEntry[]) {
    const totalXP = journal.reduce((sum, e) => sum + e.xp, 0);
    const level = Math.floor(Math.sqrt(totalXP / 150)) + 1;
    const floor = 150 * (level - 1) ** 2;
    const next = 150 * level ** 2;
    return { totalXP, level, currentXP: totalXP - floor, nextLevelXP: next - floor, progress: (totalXP - floor) / (next - floor), recipesCooked: journal.length, uniqueRecipes: new Set(journal.map(e => e.recipeId)).size, cuisines: new Set(journal.map(e => e.cuisine)).size };
}
export function achievementsFor(journal: JournalEntry[]) {
    const unique = new Set(journal.map(e => e.recipeId)).size;
    const sauces = new Set(journal.filter(e => e.skills.includes('Sauces')).map(e => e.recipeId)).size;
    const cuisines = new Set(journal.map(e => e.cuisine)).size;
    const attempts = new Map<string, number>();
    journal.forEach(e => attempts.set(e.recipeId, (attempts.get(e.recipeId) ?? 0) + 1));
    return [
        { id: 'first-flame', name: 'First Flame', description: 'Complete your first recipe.', earned: journal.length >= 1, progress: Math.min(journal.length, 1), target: 1 },
        { id: 'sauce-apprentice', name: 'Sauce Apprentice', description: 'Practise five different sauces.', earned: sauces >= 5, progress: Math.min(sauces, 5), target: 5 },
        { id: 'kitchen-explorer', name: 'Kitchen Explorer', description: 'Cook ten different recipes.', earned: unique >= 10, progress: Math.min(unique, 10), target: 10 },
        { id: 'around-the-world', name: 'Around the World', description: 'Cook recipes from five cuisines.', earned: cuisines >= 5, progress: Math.min(cuisines, 5), target: 5 },
        { id: 'signature-practice', name: 'Making It Yours', description: 'Return to the same recipe three times.', earned: [...attempts.values()].some(v => v >= 3), progress: Math.min(Math.max(0, ...attempts.values()), 3), target: 3 },
    ];
}
export function skillPractice(journal: JournalEntry[], skill: string) { const practices = journal.filter(e => e.skills.includes(skill)).length; return { practices, level: Math.floor(Math.sqrt(practices)), progress: practices / (Math.floor(Math.sqrt(practices)) + 1) ** 2 }; }
export function recipeStats(journal: JournalEntry[], recipeId: string) {
    const history = journal.filter(e => e.recipeId === recipeId);
    return { timesCooked: history.length, bestSeconds: history.length ? Math.min(...history.map(e => e.durationSeconds)) : null, averageSeconds: history.length ? Math.round(history.reduce((n, e) => n + e.durationSeconds, 0) / history.length) : null, rating: history.length ? history.reduce((n, e) => n + e.ratings.overall, 0) / history.length : null, history };
}
