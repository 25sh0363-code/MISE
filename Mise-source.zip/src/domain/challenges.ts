import type { ChallengeEnrollment, JournalEntry, Preferences } from './types.ts';
export const CHALLENGES = [
    { id: 'crispy-challenge', name: 'The Crispy Challenge', description: 'Cook oven fries and record what you learned about crispness.', period: 'daily' as const, target: 1, xp: 40 },
    { id: 'sauce-explorer', name: 'Sauce Explorer', description: 'Practise three different homemade sauce recipes.', period: 'weekly' as const, target: 3, xp: 100 },
    { id: 'kitchen-explorer-week', name: 'A New Chapter', description: 'Cook three different recipes this week. Explore at your own pace.', period: 'weekly' as const, target: 3, xp: 100 },
];
export function challengePeriod(period: 'daily' | 'weekly', now = Date.now()): string {
    const date = new Date(now);
    if (period === 'weekly')
        date.setDate(date.getDate() - (date.getDay() + 6) % 7);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function count(id: string, entries: JournalEntry[]) {
    if (id === 'crispy-challenge')
        return entries.filter(e => e.recipeId === 'crispy-french-fries' && (e.notes.trim() || e.improvements.trim())).length;
    if (id === 'sauce-explorer')
        return new Set(entries.filter(e => e.recipeCategory === 'Sauces' || (!e.recipeCategory && /sauce/i.test(e.recipeName))).map(e => e.recipeId)).size;
    return new Set(entries.map(e => e.recipeId)).size;
}
export function challengeProgress(journal: JournalEntry[], preferences: Preferences, now = Date.now()) {
    return CHALLENGES.map(challenge => {
        const enrollment = preferences.challengeEnrollments?.find(e => e.id === challenge.id && e.periodKey === challengePeriod(challenge.period, now));
        const entries = enrollment ? journal.filter(e => e.completedAt >= enrollment.enrolledAt && challengePeriod(challenge.period, e.completedAt) === enrollment.periodKey) : [];
        return { ...challenge, enrolled: !!enrollment, completed: !!enrollment?.completedAt, progress: Math.min(challenge.target, count(challenge.id, entries)), periodKey: challengePeriod(challenge.period, now) };
    });
}
export function awardChallenges(journal: JournalEntry[], preferences: Preferences, now: number): {
    enrollments: ChallengeEnrollment[];
    bonus: number;
} {
    let bonus = 0;
    const progress = challengeProgress(journal, preferences, now);
    const enrollments = (preferences.challengeEnrollments ?? []).map(enrollment => {
        const state = progress.find(c => c.id === enrollment.id && c.periodKey === enrollment.periodKey);
        if (!enrollment.completedAt && state?.enrolled && state.progress >= state.target) {
            bonus += state.xp;
            return { ...enrollment, completedAt: now, xpAwarded: state.xp };
        }
        return enrollment;
    });
    return { enrollments, bonus };
}
