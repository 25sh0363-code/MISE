import { z } from 'zod';
export const ingredientSchema = z.object({ id: z.string().min(1), name: z.string().trim().min(1).max(200), quantity: z.number().positive().max(100000), unit: z.string().max(50) });
export const stepSchema = z.object({ id: z.string().min(1), title: z.string().trim().min(1).max(200), instruction: z.string().trim().min(1).max(6000), durationSeconds: z.number().int().positive().max(86400).optional(), ingredients: z.array(z.string()).optional() });
export const recipeSchema = z.object({
    id: z.string().min(1), name: z.string().trim().min(1).max(200), description: z.string().trim().min(1).max(4000), cuisine: z.string().trim().min(1).max(100), category: z.string().trim().min(1).max(100), imageKey: z.enum(['burger', 'fries', 'sauce', 'onions', 'gourmet', 'custom', 'pasta', 'pancakes', 'chickpeas', 'bread']), imageUri: z.string().optional(),
    ingredients: z.array(ingredientSchema).min(1).max(100), steps: z.array(stepSchema).min(1).max(100), equipment: z.array(z.string().min(1)).max(50), prepMinutes: z.number().min(0).max(10080), cookMinutes: z.number().min(0).max(10080), difficulty: z.number().int().min(1).max(5), servings: z.number().int().min(1).max(100), skills: z.array(z.string()).max(20), notes: z.string().max(10000).optional(), source: z.enum(['starter', 'manual', 'ai']), collections: z.array(z.string().max(80)).max(50).optional(),
}).superRefine((r, context) => { if (new Set(r.ingredients.map(i => i.id)).size !== r.ingredients.length)
    context.addIssue({ code: z.ZodIssueCode.custom, message: 'Ingredients must have unique identifiers.', path: ['ingredients'] }); if (new Set(r.steps.map(s => s.id)).size !== r.steps.length)
    context.addIssue({ code: z.ZodIssueCode.custom, message: 'Steps must have unique identifiers.', path: ['steps'] }); });
const rating = z.number().int().min(1).max(5);
export const reviewSchema = z.object({ ratings: z.object({ taste: rating, texture: rating, presentation: rating, overall: rating }), notes: z.string().max(20000), improvements: z.string().max(20000), photos: z.array(z.string().min(1)).max(20) });
