export type ImageKey = 'burger' | 'fries' | 'sauce' | 'onions' | 'gourmet' | 'custom' | 'pasta' | 'pancakes' | 'chickpeas' | 'bread';
export type Ingredient = {
    id: string;
    name: string;
    quantity: number;
    unit: string;
};
export type RecipeStep = {
    id: string;
    title: string;
    instruction: string;
    durationSeconds?: number;
    ingredients?: string[];
};
export type Recipe = {
    id: string;
    name: string;
    description: string;
    cuisine: string;
    category: string;
    imageKey: ImageKey;
    imageUri?: string;
    ingredients: Ingredient[];
    steps: RecipeStep[];
    equipment: string[];
    prepMinutes: number;
    cookMinutes: number;
    difficulty: number;
    servings: number;
    skills: string[];
    notes?: string;
    source: 'starter' | 'manual' | 'ai';
    collections?: string[];
};
export type RecipeRecord = {
    recipe: Recipe;
    saved: boolean;
    favorite: boolean;
    archived: boolean;
    revision: number;
};
export type SessionStatus = 'preparing' | 'cooking' | 'paused' | 'reviewing' | 'completed' | 'abandoned';
export type Session = {
    id: string;
    recipe: Recipe;
    status: SessionStatus;
    stepIndex: number;
    checkedIngredients: string[];
    checkedEquipment: string[];
    startedAt: number;
    pausedAt?: number;
    pausedMs: number;
    finishedAt?: number;
    cookingStartedAt?: number;
    reviewDraft?: Partial<Review>;
};
export type Timer = {
    id: string;
    sessionId: string;
    label: string;
    endsAt: number;
    status: 'running' | 'cancelled';
    notificationId?: string;
};
export type Ratings = {
    taste: number;
    texture: number;
    presentation: number;
    overall: number;
};
export type Review = {
    ratings: Ratings;
    notes: string;
    improvements: string;
    photos: string[];
};
export type JournalEntry = Review & {
    id: string;
    sessionId: string;
    recipeId: string;
    recipeName: string;
    cuisine: string;
    skills: string[];
    recipeCategory?: string;
    challengeXP?: number;
    durationSeconds: number;
    completedAt: number;
    xp: number;
};
export type Preferences = {
    experience: string;
    cuisines: string[];
    dietary: string[];
    allergies: string;
    equipment: string[];
    goals: string[];
    challengeEnrollments?: ChallengeEnrollment[];
    onboarded: boolean;
    theme: 'system' | 'light' | 'dark';
};
export type AppSnapshot = {
    recipes: RecipeRecord[];
    sessions: Session[];
    timers: Timer[];
    journal: JournalEntry[];
    preferences: Preferences;
    pendingSync: number;
    conflicts: number;
};
export type SyncEntity = 'recipes' | 'cooking_sessions' | 'journal_entries' | 'preferences';
export type OutboxItem = {
    id: string;
    entity: SyncEntity;
    entityId: string;
    operation: 'upsert' | 'delete';
    payload: string;
    baseRevision: number;
    createdAt: number;
    attempts: number;
    ownerId?: string;
};
export type Conflict = {
    id: string;
    entity: SyncEntity;
    entityId: string;
    localPayload: string;
    remotePayload: string;
    createdAt: number;
};
export type ChallengeEnrollment = {
    id: string;
    periodKey: string;
    enrolledAt: number;
    completedAt?: number;
    xpAwarded: number;
};
