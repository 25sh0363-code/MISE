import { create } from 'zustand';
import { Alert } from 'react-native';
import type { AppSnapshot } from '../domain/types';
import type { MiseRepository } from '../db/repository';
import { openRepository } from '../db/expo';
type MiseState = {
    snapshot: AppSnapshot | null;
    ready: boolean;
    error: string | null;
    busy: boolean;
    repo: MiseRepository;
    toast: string | null;
    init: () => Promise<void>;
    refresh: () => Promise<void>;
    act: <T>(fn: (repo: MiseRepository) => Promise<T>) => Promise<T>;
    notify: (message: string | null) => void;
};
let opening: Promise<MiseRepository> | undefined;
let activeOperations = 0;
const getRepository = () => opening ??= openRepository();
export const useMise = create<MiseState>((set, get) => ({
    snapshot: null, ready: false, error: null, busy: false,
    // No screen can access this before initialization has completed.
    repo: undefined as unknown as MiseRepository,
    toast: null,
    init: async () => {
        try {
            const repo = await getRepository();
            set({ repo, snapshot: await repo.snapshot(), ready: true, error: null });
        }
        catch (error) {
            set({ ready: false, error: error instanceof Error ? error.message : 'Your kitchen could not open.' });
            opening = undefined;
        }
    },
    refresh: async () => {
        const repo = await getRepository();
        set({ snapshot: await repo.snapshot() });
    },
    act: async <T,>(fn: (repo: MiseRepository) => Promise<T>): Promise<T> => {
        activeOperations += 1;
        set({ busy: true });
        try {
            const result = await fn(await getRepository());
            await get().refresh();
            return result;
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Please try again.';
            Alert.alert('Let’s try that again', message);
            throw error;
        }
        finally {
            activeOperations -= 1;
            set({ busy: activeOperations > 0 });
        }
    },
    notify: (toast) => set({ toast }),
}));
