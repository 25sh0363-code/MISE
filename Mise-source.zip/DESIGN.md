# MISE design system

Native iOS and Android. The user’s supplied warm editorial identity governs the world. Screen composition follows native tab and stack navigation. No browser surface ships.

## Palette and appearance
Ivory (#F8F5EF) is the daylight page; cream (#EFE8DA) groups supporting tasks; forest (#344E41) identifies primary actions. Espresso (#29251F) carries reading. Terracotta and gold are reserved for meaningful emphasis and earned milestones. Muted text is darkened for legibility. Night mode uses warm forest surfaces with ivory text and sage controls.

## Typography
A restrained serif marks recipe names and personal greeting moments. Body, labels and controls follow platform system sans typography. All native Text components retain system text scaling. Display titles are editorial, body copy reads at 17sp/pt, support copy at 13sp/pt. Custom branding remains limited to display moments.

## Composition
The Kitchen leads with a greeting, honest practice progress, and one food photograph. It then offers a clear cooking choice. Discover searches across ingredients, cuisines and techniques with scope filters. Cookbook uses the same collectible recipe system with meaningful saved and favourite states. Journey ties every progress number to recorded journal entries. Chef discloses cloud configuration and AI origin; generated drafts require confirmation before persistence.

## Interaction
48-point controls, safe area insets, platform stack gestures and bottom tabs. Recipe cards support an alternate swipe-to-save gesture alongside a visible bookmark button. Reanimated progress respects reduced motion. Native alerts protect deletion and recipe draft confirmation. Contextual cooking and journal routes do not occupy permanent tabs.

## Content and verification
Never fabricate meals, XP, badges, history, or AI responses. Bundled recipe photography is illustrative, not a user's cooking photograph. Other recipes use honest cuisine and category artwork until the user adds photographs. Simulator and emulator captures are required before a release; this environment has no native simulator or Android SDK.
