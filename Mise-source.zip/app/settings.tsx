import { useState, useEffect } from 'react';
import { View, Alert } from 'react-native';
import { router } from 'expo-router';
import { useMise } from '../src/state/app';
import { useTheme } from '../src/theme';
import { cloudConfigured, getAccount, signIn, signUp, signOut } from '../src/services/cloud';
import { syncNow } from '../src/services/sync';
import { ConflictReview } from '../src/components/conflicts';
import { Screen, Text, Section, Button, Chip, Field, Divider } from '../src/components/ui';
export default function Settings() { const { snapshot, act, refresh, notify, repo } = useMise(); const { colors } = useTheme(); const [account, setAccount] = useState<{
    id: string;
    email?: string;
} | null>(null); const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [pending, setPending] = useState(false); const [error, setError] = useState(''); const [allergies, setAllergies] = useState(snapshot?.preferences.allergies || ''); useEffect(() => { void getAccount().then(setAccount).catch(e => setError(String(e.message))); }, []); if (!snapshot)
    return null; const authenticate = async (create: boolean) => { setPending(true); setError(''); try {
    if (create) {
        const result = await signUp(email, password);
        notify(result.confirmationRequired ? 'Check your email to confirm your account.' : 'Your account is ready.');
    }
    else
        await signIn(email, password);
    setAccount(await getAccount());
    setPassword('');
}
catch (e) {
    setError(e instanceof Error ? e.message : 'Could not connect. Please try again.');
}
finally {
    setPending(false);
} }; return <Screen edges={['left', 'right']}><Text variant="display">Your kitchen,{'\n'}your way.</Text><Section title="Appearance"><View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>{(['system', 'light', 'dark'] as const).map(theme => <Chip key={theme} label={theme.charAt(0).toUpperCase() + theme.slice(1)} selected={snapshot.preferences.theme === theme} onPress={() => { void act(r => r.updatePreferences({ theme })).catch(() => { }); }}/>)}</View></Section><Section title="Your cooking preferences"><Text color={colors.muted}>{snapshot.preferences.experience} · {snapshot.preferences.cuisines.join(', ') || 'All cuisines welcome'}</Text><Field label="Allergies & ingredients to avoid" value={allergies} onChangeText={setAllergies} multiline placeholder="Ingredients you need to avoid"/><Button label="Save allergy preferences" variant="secondary" onPress={() => { void act(r => r.updatePreferences({ allergies })).then(() => notify('Preferences saved. Always review ingredient labels.')).catch(() => { }); }}/><Button label="Edit all cooking preferences" variant="ghost" onPress={() => router.push('/onboarding')}/></Section><Divider /><Section title="Cloud & account"><View style={{ gap: 8 }}><Text variant="heading">{cloudConfigured ? 'Your connected kitchen' : 'Local kitchen mode'}</Text><Text color={colors.muted}>{cloudConfigured ? 'Sign in to synchronize your kitchen and ask AI Chef for help.' : 'This build has no cloud credentials. Your cookbook, cooking sessions and journal are saved on this device. AI and account sync become available after configuring your own Supabase project.'}</Text><Text variant="caption" color={colors.muted}>{snapshot.pendingSync} local changes awaiting sync{snapshot.conflicts ? ` · ${snapshot.conflicts} conflicts kept for review` : ''}</Text></View>{cloudConfigured && (account ? <View style={{ gap: 12 }}><Text>Signed in as {account.email || 'Chef'}</Text><Button label="Sync your kitchen" icon="sync-outline" loading={pending} onPress={() => { setPending(true); setError(''); void syncNow(repo).then(async (result) => { await refresh(); notify(`Synced ${result.pushed + result.pulled} changes${result.conflicts ? `; ${result.conflicts} conflicts preserved` : ''}.`); }).catch(e => setError(e.message)).finally(() => setPending(false)); }}/><Button label="Sign out" variant="secondary" onPress={() => Alert.alert('Sign out?', 'Your local recipes and journal will remain on this device.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', onPress: () => { void signOut().then(() => setAccount(null)).catch(e => setError(e.message)); } }])}/></View> : <View style={{ gap: 14 }}><Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email"/><Field label="Password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoComplete="password"/><Button label="Sign in" loading={pending} disabled={!email.trim() || !password} onPress={() => { void authenticate(false); }}/><Button label="Create an account" variant="secondary" disabled={pending || !email.trim() || password.length < 8} onPress={() => { void authenticate(true); }}/></View>)}{error && <Text accessibilityRole="alert" color={colors.danger}>{error}</Text>}<ConflictReview /></Section><Divider /><Section title="A little about Mise"><Text color={colors.muted}>A personal place to cook, learn and keep the meals that made you smile. Progress comes from the recipes you complete and review.</Text><Text variant="caption" color={colors.muted}>Version 1.0 · Native local development build</Text></Section></Screen>; }
