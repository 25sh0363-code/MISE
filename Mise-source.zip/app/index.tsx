import { Redirect } from 'expo-router';
import { useMise } from '../src/state/app';
export default function Index() { const { snapshot } = useMise(); return <Redirect href={snapshot?.preferences.onboarded ? '/(tabs)' : '/onboarding'}/>; }
