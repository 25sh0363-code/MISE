import React, { useState } from 'react';
import { View, Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Screen, Text, Button, Field, IconButton, Chip, Divider } from '../../src/components/ui';
import { useTheme } from '../../src/theme';
import { useMise } from '../../src/state/app';
import type { Recipe, Ingredient, RecipeStep } from '../../src/domain/types';
import { SKILLS } from '../../src/domain/progression';
import { recipeSchema } from '../../src/domain/schemas';
import { pickCookingPhoto } from '../../src/services/photos';
const uid = () => `manual-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const newIngredient = (): Ingredient => ({ id: uid(), name: '', quantity: 1, unit: 'g' });
const newStep = (): RecipeStep => ({ id: uid(), title: '', instruction: '' });
export default function RecipeEditor() {
    const { id } = useLocalSearchParams<{
        id?: string;
    }>();
    const { snapshot, act, busy, notify } = useMise();
    const { colors } = useTheme();
    const original = snapshot?.recipes.find(record => record.recipe.id === id)?.recipe;
    const [recipe, setRecipe] = useState<Recipe>(() => original ? { ...original, source: original.source === 'starter' ? 'manual' : original.source } : { id: uid(), name: '', description: '', cuisine: '', category: 'Dinner', imageKey: 'custom', ingredients: [newIngredient()], steps: [newStep()], equipment: ['Frying pan'], prepMinutes: 10, cookMinutes: 15, difficulty: 1, servings: 2, skills: ['Food Preparation'], source: 'manual', collections: [] });
    const [equipment, setEquipment] = useState(recipe.equipment.join(', '));
    const [collections, setCollections] = useState(recipe.collections?.join(', ') ?? '');
    const [validation, setValidation] = useState<string | null>(null);
    function patch<K extends keyof Recipe>(key: K, value: Recipe[K]) { setRecipe(r => ({ ...r, [key]: value })); }
    function ingredient(id: string, update: Partial<Ingredient>) { setRecipe(r => ({ ...r, ingredients: r.ingredients.map(i => i.id === id ? { ...i, ...update } : i) })); }
    function step(id: string, update: Partial<RecipeStep>) { setRecipe(r => ({ ...r, steps: r.steps.map(s => s.id === id ? { ...s, ...update } : s) })); }
    async function cover() { try {
        const uri = await pickCookingPhoto();
        if (uri)
            patch('imageUri', uri);
    }
    catch (e) {
        Alert.alert('Photo access', e instanceof Error ? e.message : 'Could not add this photograph.');
    } }
    async function save() {
        const candidate = { ...recipe, name: recipe.name.trim(), description: recipe.description.trim(), cuisine: recipe.cuisine.trim(), equipment: equipment.split(',').map(x => x.trim()).filter(Boolean), collections: collections.split(',').map(x => x.trim()).filter(Boolean) };
        const parsed = recipeSchema.safeParse(candidate);
        if (!parsed.success) {
            setValidation(parsed.error.issues.map(issue => `${issue.path.join(' › ')}: ${issue.message}`).slice(0, 4).join('\n'));
            return;
        }
        Alert.alert(original ? 'Save your changes?' : 'Add to your cookbook?', 'This saves your recipe on this device. Active cooking sessions keep the version they started with.', [{ text: 'Keep editing', style: 'cancel' }, { text: 'Save recipe', onPress: () => { void act(repo => repo.putRecipe(candidate)).then(() => { notify('Recipe saved to your cookbook.'); router.replace({ pathname: '/recipe/[id]', params: { id: candidate.id } }); }).catch(() => undefined); } }]);
    }
    return <Screen><Text variant="display">{original ? 'Make it yours.' : 'A recipe worth keeping.'}</Text><Text color={colors.muted}>From a family favourite to your next experiment.</Text><Field label="Recipe name" value={recipe.name} onChangeText={v => patch('name', v)} placeholder="Sunday tomato pasta" maxLength={150}/><Field label="A little description" value={recipe.description} onChangeText={v => patch('description', v)} multiline maxLength={2000}/><Field label="Cuisine" value={recipe.cuisine} onChangeText={v => patch('cuisine', v)} placeholder="Italian" maxLength={80}/><Field label="Meal category" value={recipe.category} onChangeText={v => patch('category', v)} maxLength={80}/>
    <View style={{ flexDirection: 'row', gap: 12 }}><View style={{ flex: 1 }}><Field label="Prep · minutes" keyboardType="number-pad" value={String(recipe.prepMinutes)} onChangeText={v => patch('prepMinutes', Number(v))}/></View><View style={{ flex: 1 }}><Field label="Cook · minutes" keyboardType="number-pad" value={String(recipe.cookMinutes)} onChangeText={v => patch('cookMinutes', Number(v))}/></View></View><Field label="Servings" keyboardType="number-pad" value={String(recipe.servings)} onChangeText={v => patch('servings', Number(v))}/><Text variant="label">Difficulty</Text><View style={{ flexDirection: 'row', gap: 8 }}>{[1, 2, 3, 4, 5].map(level => <Chip key={level} label={String(level)} selected={recipe.difficulty === level} onPress={() => patch('difficulty', level)}/>)}</View><Button label={recipe.imageUri ? 'Change cover photograph' : 'Add cover photograph'} icon="camera-outline" variant="secondary" onPress={() => void cover()}/><Divider />
    <Text variant="title">Ingredients</Text>{recipe.ingredients.map((item, index) => <View key={item.id} style={{ gap: 12 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ flex: 1 }}><Field label={`Ingredient ${index + 1}`} value={item.name} onChangeText={name => ingredient(item.id, { name })} maxLength={200}/></View><IconButton name="trash-outline" label={`Remove ingredient ${index + 1}`} onPress={() => patch('ingredients', recipe.ingredients.filter(i => i.id !== item.id))}/></View><View style={{ flexDirection: 'row', gap: 12 }}><View style={{ flex: 1 }}><Field label="Quantity" keyboardType="decimal-pad" value={String(item.quantity)} onChangeText={quantity => ingredient(item.id, { quantity: Number(quantity) })}/></View><View style={{ flex: 1 }}><Field label="Unit" value={item.unit} onChangeText={unit => ingredient(item.id, { unit })} placeholder="g, ml, tbsp, whole" maxLength={50}/></View></View></View>)}<Button label="Add ingredient" icon="add" variant="secondary" onPress={() => patch('ingredients', [...recipe.ingredients, newIngredient()])} disabled={recipe.ingredients.length >= 60}/><Divider />
    <Text variant="title">Method</Text>{recipe.steps.map((item, index) => <View key={item.id} style={{ gap: 12 }}><View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text variant="heading">Step {index + 1}</Text><IconButton name="trash-outline" label={`Remove step ${index + 1}`} onPress={() => patch('steps', recipe.steps.filter(s => s.id !== item.id))}/></View><Field label="Step title" value={item.title} onChangeText={title => step(item.id, { title })} maxLength={150}/><Field label="Instructions" value={item.instruction} onChangeText={instruction => step(item.id, { instruction })} multiline maxLength={4000} style={{ minHeight: 110 }}/><Field label="Optional timer · seconds" value={item.durationSeconds ? String(item.durationSeconds) : ''} onChangeText={duration => step(item.id, { durationSeconds: duration ? Number(duration) : undefined })} keyboardType="number-pad" placeholder="For example, 180 for 3 minutes"/></View>)}<Button label="Add cooking step" icon="add" variant="secondary" onPress={() => patch('steps', [...recipe.steps, newStep()])} disabled={recipe.steps.length >= 40}/><Divider />
    <Field label="Equipment · separated by commas" value={equipment} onChangeText={setEquipment} placeholder="Frying pan, knife, food thermometer"/><Field label="Collections · separated by commas" value={collections} onChangeText={setCollections} placeholder="Weeknight favourites, Family recipes"/><Text variant="title">Skills you’ll practise</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{SKILLS.map(skill => <Chip key={skill} label={skill} selected={recipe.skills.includes(skill)} onPress={() => patch('skills', recipe.skills.includes(skill) ? recipe.skills.filter(s => s !== skill) : [...recipe.skills, skill])}/>)}</View><Field label="Personal notes" value={recipe.notes ?? ''} onChangeText={v => patch('notes', v)} multiline maxLength={4000}/>{!!validation && <Text color={colors.danger} accessibilityRole="alert">{validation}</Text>}<Button label="Save recipe" icon="bookmark-outline" disabled={busy} onPress={() => void save()}/>
  </Screen>;
}
