import { useState, useEffect } from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useMise } from '../../src/state/app';
import { useTheme } from '../../src/theme';
import { journeys } from '../../src/data/journeys';
import { Screen, Text, Button, RecipeCard, Section, Chip, Field, Empty, Progress, type IconName } from '../../src/components/ui';
export default function Discover() {
    const { snapshot, act, notify } = useMise();
    const { colors } = useTheme();
    const params = useLocalSearchParams<{
        query?: string;
        journey?: string;
    }>();
    const [search, setSearch] = useState(params.query || '');
    const [filter, setFilter] = useState('All');
    const [journeyId, setJourneyId] = useState<string | undefined>(params.journey);
    useEffect(() => { setSearch(params.query || ''); setJourneyId(params.journey); }, [params.query, params.journey]);
    if (!snapshot)
        return null;
    const cuisines = [...new Set(snapshot.recipes.map(r => r.recipe.cuisine))];
    const all = snapshot.recipes.filter(r => !r.archived);
    const journey = journeys.find(j => j.id === journeyId);
    const recipes = all.filter(({ recipe: r }) => `${r.name} ${r.cuisine} ${r.category} ${r.skills.join(' ')} ${r.ingredients.map(i => i.name).join(' ')}`.toLowerCase().includes(search.toLowerCase()) && (filter === 'All' || (filter === 'Quick' ? r.prepMinutes + r.cookMinutes <= 30 : filter === 'Beginner' ? r.difficulty <= 2 : r.cuisine === filter)) && (!journey || (journey.recipeIds as readonly string[]).includes(r.id))).sort((a, b) => journey ? (journey.recipeIds as readonly string[]).indexOf(a.recipe.id) - (journey.recipeIds as readonly string[]).indexOf(b.recipe.id) : 0);
    const cooked = new Set(snapshot.journal.map(j => j.recipeId));
    const available = journey ? journey.recipeIds.filter(id => all.some(r => r.recipe.id === id)) : [];
    const done = available.filter(id => cooked.has(id)).length;
    return <Screen><Text variant="display">Follow your appetite.</Text><Text color={colors.muted}>A familiar favourite. A new little adventure.</Text><Field label="Find a recipe" value={search} onChangeText={setSearch} placeholder="Ingredients, cuisines, techniques…" returnKeyType="search"/>
 <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{['All', 'Quick', 'Beginner', ...cuisines].map(c => <Chip key={c} label={c} selected={filter === c} onPress={() => setFilter(c)}/>)}</ScrollView>
 {!search && filter === 'All' && !journey && <Section title="Take the scenic route"><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 14, paddingBottom: 8 }}>{journeys.map(j => { const count = j.recipeIds.filter(id => all.some(r => r.recipe.id === id)).length; return <Pressable key={j.id} accessibilityRole="button" accessibilityLabel={`Explore ${j.name}`} onPress={() => setJourneyId(j.id)} style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, width: 245, gap: 12 }}><Ionicons name={j.icon as IconName} color={colors.primary} size={28}/><Text variant="title">{j.name}</Text><Text variant="caption" color={colors.muted}>{j.description}</Text><Text variant="label" color={colors.primary}>{count} {count === 1 ? 'recipe' : 'recipes'} to explore →</Text></Pressable>; })}</ScrollView></Section>}
 {journey && <View style={{ backgroundColor: colors.primary, borderRadius: 16, padding: 24, gap: 14 }}><Ionicons name={journey.icon as IconName} size={29} color={colors.onPrimary}/><Text variant="title" color={colors.onPrimary}>{journey.name}</Text><Text color={colors.onPrimary}>{journey.description}</Text><Text variant="caption" color={colors.onPrimary}>{done} of {available.length} recipes practised · explore at your own pace</Text><Progress value={available.length ? done / available.length : 0} color={colors.onPrimary} trackColor={colors.sage}/><Button label="All culinary journeys" variant="secondary" onPress={() => setJourneyId(undefined)}/></View>}
 <Section title={journey ? 'Your learning path' : search ? 'Your discoveries' : 'Something delicious awaits'} action="Surprise me" onAction={() => { if (all.length)
        router.push(`/recipe/${all[Math.floor(Math.random() * all.length)].recipe.id}`); }}>{recipes.length ? recipes.map(r => <RecipeCard key={r.recipe.id} recipe={r.recipe} saved={r.saved} onPress={() => router.push(`/recipe/${r.recipe.id}`)} onSave={() => { void act(repo => repo.saveRecipe(r.recipe.id)).then(() => notify('Saved to your cookbook.')).catch(() => { }); }}/>) : <Empty title="A new recipe is waiting" description="Try another ingredient or clear the filters to explore the collection." action="Clear filters" onAction={() => { setSearch(''); setFilter('All'); setJourneyId(undefined); }}/>}</Section>
 <Section title="Make it your own"><Text color={colors.muted}>Your cookbook can hold any cuisine. Add a family recipe or ask Chef to help you create something new.</Text><Button label="Add your recipe" variant="secondary" icon="add-outline" onPress={() => router.push('/recipe/edit')}/></Section></Screen>;
}
