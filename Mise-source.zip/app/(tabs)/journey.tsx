import { View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMise } from '../../src/state/app';
import { useTheme } from '../../src/theme';
import { chefProgress, achievementsFor, skillPractice, SKILLS } from '../../src/domain/progression';
import { journeys } from '../../src/data/journeys';
import { Screen, Text, Section, Progress, Button, Divider, type IconName } from '../../src/components/ui';
import { ChallengeList } from '../../src/components/challenges';
export default function Journey() {
    const { snapshot } = useMise();
    const { colors } = useTheme();
    if (!snapshot)
        return null;
    const progress = chefProgress(snapshot.journal);
    const badges = achievementsFor(snapshot.journal);
    const cooked = new Set(snapshot.journal.map(j => j.recipeId));
    return <Screen><Text variant="display">A little better,{'\n'}every time.</Text><Text color={colors.muted}>Your journey grows with the meals you make.</Text>
 <View style={{ alignItems: 'center', padding: 20, gap: 12 }}><View style={{ width: 92, height: 92, borderRadius: 46, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="leaf-outline" size={43} color={colors.primary}/></View><Text variant="title">Level {progress.level} · {progress.level === 1 ? 'Curious Cook' : 'Growing Chef'}</Text><Text color={colors.muted}>{progress.totalXP} XP earned through practice</Text><View style={{ alignSelf: 'stretch', gap: 8 }}><Progress value={progress.progress}/><Text variant="caption" color={colors.muted}>{progress.nextLevelXP - progress.currentXP} XP to your next level</Text></View></View>
 <View style={{ flexDirection: 'row', gap: 18, justifyContent: 'space-between', paddingVertical: 12 }}>{[[progress.recipesCooked, 'Meals cooked'], [progress.uniqueRecipes, 'Recipes tried'], [progress.cuisines, 'Cuisines']].map(([n, label]) => <View key={label} style={{ flex: 1, gap: 4 }}><Text variant="title">{n}</Text><Text variant="caption" color={colors.muted}>{label}</Text></View>)}</View>
 <Button label="Open your cooking journal" icon="journal-outline" variant="secondary" onPress={() => router.push('/journal')}/>
 <Section title="A little kitchen challenge"><ChallengeList /></Section>
 <Section title="Choose your next adventure">{journeys.map(j => { const available = j.recipeIds.filter(id => snapshot.recipes.some(r => r.recipe.id === id && !r.archived)); const done = available.filter(id => cooked.has(id)).length; return <Pressable key={j.id} accessibilityRole="button" onPress={() => router.push({ pathname: '/(tabs)/discover', params: { journey: j.id } })} style={{ paddingVertical: 18, gap: 10, borderBottomWidth: 1, borderBottomColor: colors.border }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><Ionicons name={j.icon as IconName} color={colors.primary} size={26}/><Text variant="title" style={{ flex: 1 }}>{j.name}</Text><Ionicons name="chevron-forward" color={colors.muted} size={18}/></View><Text variant="caption" color={colors.muted}>{j.description}</Text><Progress value={available.length ? done / available.length : 0}/><Text variant="caption" color={colors.muted}>{done} of {available.length} recipes practised · no locked recipes</Text></Pressable>; })}</Section>
 <Section title="Your kitchen skills">{SKILLS.map(skill => { const s = skillPractice(snapshot.journal, skill); return <Pressable key={skill} accessibilityRole="button" accessibilityLabel={`Find recipes to practise ${skill}`} onPress={() => router.push({ pathname: '/(tabs)/discover', params: { query: skill } })} style={{ gap: 8, paddingVertical: 12 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}><Text variant="label" style={{ flex: 1 }}>{skill}</Text><Text variant="caption" color={colors.muted}>{s.practices} practices →</Text></View><Progress value={s.progress}/></Pressable>; })}</Section>
 <Section title="Small moments. Big milestones.">{badges.map(b => <View key={b.id} style={{ flexDirection: 'row', gap: 16, paddingVertical: 14, alignItems: 'center' }}><Ionicons name={b.earned ? 'ribbon' : 'ribbon-outline'} size={34} color={b.earned ? colors.gold : colors.muted}/><View style={{ flex: 1, gap: 4 }}><Text variant="heading">{b.name}</Text><Text variant="caption" color={colors.muted}>{b.description}</Text><Text variant="caption" color={b.earned ? colors.primary : colors.muted}>{b.earned ? 'Earned' : `${b.progress} / ${b.target}`}</Text></View></View>)}</Section>
 <Divider /><Text variant="caption" color={colors.muted}>A recipe can be a beginning, not a test. Explore advanced recipes whenever you feel ready.</Text></Screen>;
}
