import React, { useEffect, useState } from 'react';
import { View, Linking } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useMise } from '../../src/state/app';
import { useTheme } from '../../src/theme';
import { Screen, Text, Field, Button, IconButton, Chip } from '../../src/components/ui';
import { formatDuration, timerRemaining } from '../../src/domain/progression';
import { dismissTimer, startTimer } from '../../src/services/timers';
export default function Timers() {
    const { sessionId } = useLocalSearchParams<{
        sessionId: string;
    }>();
    const { snapshot, act, busy, notify } = useMise();
    const { colors } = useTheme();
    const [label, setLabel] = useState('Kitchen timer');
    const [minutes, setMinutes] = useState('5');
    const [now, setNow] = useState(Date.now());
    useEffect(() => { const interval = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(interval); }, []);
    const session = snapshot?.sessions.find(s => s.id === sessionId);
    const timers = snapshot?.timers.filter(t => t.sessionId === sessionId && t.status === 'running') ?? [];
    const valid = Number.isFinite(Number(minutes)) && Number(minutes) > 0 && Number(minutes) <= 720;
    return <Screen><Text variant="title">A little help with timing.</Text><Text color={colors.muted}>Timers keep their deadlines when you leave Mise. Pausing cooking does not pause a timer.</Text>
    {timers.map(timer => <View key={timer.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 }}><View style={{ flex: 1 }}><Text variant="label">{timer.label}</Text><Text variant="title" color={colors.primary}>{timerRemaining(timer.endsAt, now) ? formatDuration(timerRemaining(timer.endsAt, now)) : 'Ready to check'}</Text></View><IconButton name="close" label={`Dismiss ${timer.label}`} onPress={() => void act(repo => dismissTimer(repo, timer.id)).catch(() => undefined)}/></View>)}
    {session && !['completed', 'reviewing', 'abandoned'].includes(session.status) && <><Field label="Timer name" value={label} onChangeText={setLabel} maxLength={80}/><Field label="Minutes" value={minutes} onChangeText={setMinutes} keyboardType="decimal-pad"/><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{[1, 3, 5, 10, 20].map(n => <Chip key={n} label={`${n} min`} selected={Number(minutes) === n} onPress={() => setMinutes(String(n))}/>)}</View><Button label="Start timer" icon="timer-outline" disabled={!valid || !label.trim() || busy} onPress={() => void act(repo => startTimer(repo, sessionId, label.trim(), Math.round(Number(minutes) * 60))).then(result => notify(result.notificationScheduled ? 'Timer saved and notification scheduled.' : 'Timer saved. Allow notifications in system settings for background alerts.')).catch(() => undefined)}/></>}
    <Button label="Notification settings" variant="ghost" onPress={() => void Linking.openSettings()}/><Text variant="caption" color={colors.muted}>Background alerts depend on notification permission and device settings. Use a food thermometer to check safe doneness.</Text>
  </Screen>;
}
