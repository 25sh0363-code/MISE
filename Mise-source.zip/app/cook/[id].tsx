import React, { useEffect, useState } from 'react';
import { View, Pressable, ScrollView, Alert, Switch, StyleSheet, AppState } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import * as Haptics from 'expo-haptics';
import { useMise } from '../../src/state/app';
import { useTheme } from '../../src/theme';
import { Text, Button, IconButton, Progress, Divider } from '../../src/components/ui';
import { elapsedSeconds, formatDuration, timerRemaining } from '../../src/domain/progression';
import { startTimer, dismissTimer, reconcileTimers } from '../../src/services/timers';
export default function CookingScreen() {
    const { id } = useLocalSearchParams<{
        id: string;
    }>();
    const { snapshot, act, busy, notify } = useMise();
    const { colors } = useTheme();
    const [now, setNow] = useState(Date.now());
    const [spoken, setSpoken] = useState(false);
    const session = snapshot?.sessions.find(s => s.id === id);
    useEffect(() => { const interval = setInterval(() => setNow(Date.now()), 1000); return () => { clearInterval(interval); void Speech.stop(); }; }, []);
    const step = session?.recipe.steps[session.stepIndex];
    useEffect(() => {
        void Speech.stop();
        if (spoken && step && session?.status === 'cooking')
            Speech.speak(`${step.title}. ${step.instruction}`, { rate: 0.85 });
        return () => { void Speech.stop(); };
    }, [spoken, step?.id, session?.status]);
    useEffect(() => { const sub = AppState.addEventListener('change', state => { if (state !== 'active')
        void Speech.stop(); }); return () => sub.remove(); }, []);
    if (!session)
        return <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]}><Text variant="title">This cooking session is unavailable.</Text><Button label="Back to my kitchen" onPress={() => router.replace('/(tabs)')}/></SafeAreaView>;
    const recipe = session.recipe;
    const timers = snapshot!.timers.filter(t => t.sessionId === session.id && t.status === 'running');
    const ingredientsReady = session.checkedIngredients.length === recipe.ingredients.length;
    const equipmentReady = session.checkedEquipment.length === recipe.equipment.length;
    const mutate = (fn: Parameters<typeof act>[0]) => void act(fn).catch(() => undefined);
    function leave() {
        void Speech.stop();
        router.back();
    }
    function toggleCheck(kind: 'checkedIngredients' | 'checkedEquipment', key: string) {
        const list = session![kind];
        mutate(repo => repo.updateSession(id, { [kind]: list.includes(key) ? list.filter(x => x !== key) : [...list, key] }));
    }
    async function addStepTimer() {
        if (!step?.durationSeconds || busy)
            return;
        try {
            const result = await act(repo => startTimer(repo, id, step.title, step.durationSeconds!));
            notify(result.notificationScheduled ? 'Timer set. We’ll let you know when it’s ready.' : 'Timer saved. Enable notifications in system settings for background alerts.');
        }
        catch { /* act provides a recoverable message */ }
    }
    async function next() {
        if (session!.stepIndex < recipe.steps.length - 1) {
            mutate(repo => repo.nextStep(id));
            return;
        }
        Alert.alert('Ready to plate up?', 'Finish when your food is cooked safely. Your actual time will be recorded now; the review can wait.', [
            { text: 'Keep cooking', style: 'cancel' },
            { text: 'Finish cooking', onPress: () => { void act(repo => repo.finishCooking(id)).then(() => { void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); router.replace({ pathname: '/session/[id]', params: { id } }); }).catch(() => undefined); } },
        ]);
    }
    return <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={[styles.safe, { backgroundColor: colors.bg }]}>
    <View style={styles.top}><IconButton name="chevron-down" label="Leave cooking; session is saved" onPress={leave}/><View style={{ flex: 1 }}><Text variant="caption" color={colors.muted}>In your kitchen</Text><Text variant="label" numberOfLines={2}>{recipe.name}</Text></View><Text variant="label" color={colors.primary}>{formatDuration(elapsedSeconds(session, now))}</Text></View>
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      {session.status === 'preparing' ? <>
        <Text variant="display">A little prep.{'\n'}A great meal.</Text>
        <Text color={colors.muted}>Gather your ingredients and equipment. Everything is saved as you go.</Text>
        <View style={styles.facts}><Text variant="label">{recipe.prepMinutes + recipe.cookMinutes} min</Text><Text color={colors.muted}>Serves {recipe.servings}</Text><Text color={colors.muted}>Difficulty {recipe.difficulty}/5</Text></View>
        <Text variant="title">Ingredients</Text>
        {recipe.ingredients.map(ingredient => <CheckRow key={ingredient.id} checked={session.checkedIngredients.includes(ingredient.id)} label={`${ingredient.quantity} ${ingredient.unit} ${ingredient.name}`} onPress={() => toggleCheck('checkedIngredients', ingredient.id)}/>)}
        <Divider /><Text variant="title">Equipment</Text>
        {recipe.equipment.map(item => <CheckRow key={item} checked={session.checkedEquipment.includes(item)} label={item} onPress={() => toggleCheck('checkedEquipment', item)}/>)}
        {!!recipe.notes && <Text color={colors.muted}>{recipe.notes}</Text>}
        <Text variant="caption" color={colors.muted}>Wash hands and produce. Keep raw meat separate. A timer estimates time; a food thermometer checks doneness.</Text>
        <Button label={ingredientsReady && equipmentReady ? 'Everything’s ready. Let’s cook.' : 'Check ingredients & equipment to begin'} disabled={busy || !ingredientsReady || !equipmentReady} icon="flame-outline" onPress={() => mutate(repo => repo.beginCooking(id))}/>
      </> : session.status === 'reviewing' || session.status === 'completed' || session.status === 'abandoned' ? <>
        <Text variant="display">{session.status === 'abandoned' ? 'A fresh start awaits.' : 'Your cooking is saved.'}</Text><Text color={colors.muted}>{session.status === 'abandoned' ? 'This session ended without a journal entry or XP. Your recipe is still here when you need it.' : 'Take a moment to reflect on what worked and what you’ll try next.'}</Text><Button label={session.status === 'abandoned' ? 'Back to my kitchen' : session.status === 'completed' ? 'View cooking journal' : 'Review my dish'} onPress={() => router.replace(session.status === 'abandoned' ? '/(tabs)' : session.status === 'completed' ? '/journal' : { pathname: '/session/[id]', params: { id } })}/>
      </> : <>
        <View style={{ gap: 12 }}><View style={styles.between}><Text variant="label" color={colors.primary}>Step {session.stepIndex + 1} of {recipe.steps.length}</Text><Text variant="caption" color={colors.muted}>{Math.round((session.stepIndex / recipe.steps.length) * 100)}% complete</Text></View><Progress value={(session.stepIndex + 1) / recipe.steps.length}/></View>
        <Text variant="display" style={{ marginTop: 12 }}>{step?.title}</Text>
        <Text style={{ fontSize: 24, lineHeight: 36 }}>{step?.instruction}</Text>
        {!!step?.ingredients?.length && <View style={[styles.ingredientNote, { backgroundColor: colors.surface }]}><Text variant="label">For this step</Text>{step.ingredients.map(item => { const ingredient = recipe.ingredients.find(i => i.id === item); return <Text key={item} color={colors.muted}>{ingredient ? `${ingredient.quantity} ${ingredient.unit} ${ingredient.name}` : item}</Text>; })}</View>}
        {!!step?.durationSeconds && <Button label={`Set ${formatDuration(step.durationSeconds)} timer`} icon="timer-outline" variant="secondary" onPress={() => void addStepTimer()} disabled={busy || session.status === 'paused'}/>}
        <View style={styles.between}><View style={{ flex: 1 }}><Text variant="label">Read instructions aloud</Text><Text variant="caption" color={colors.muted}>Spoken while the app is open</Text></View><Switch accessibilityLabel="Read instructions aloud" value={spoken} onValueChange={setSpoken} trackColor={{ true: colors.primary }}/></View>
        {session.status === 'paused' && <View style={[styles.ingredientNote, { backgroundColor: colors.surface }]}><Text variant="heading">Take your time.</Text><Text color={colors.muted}>Session paused. Kitchen timers keep running—check food on the heat.</Text><Button label="Resume cooking" onPress={() => mutate(repo => repo.resumeSession(id))}/></View>}
        <View style={styles.between}><Button label="Previous" variant="ghost" disabled={session.stepIndex === 0 || busy || session.status === 'paused'} onPress={() => mutate(repo => repo.previousStep(id))}/><View style={{ flex: 1 }}><Button label={session.stepIndex === recipe.steps.length - 1 ? 'Finish cooking' : 'Next step'} icon={session.stepIndex === recipe.steps.length - 1 ? 'checkmark' : 'arrow-forward'} disabled={busy || session.status === 'paused'} onPress={() => void next()}/></View></View>
      </>}
      {!['completed', 'abandoned'].includes(session.status) && <Button label="End session without recording" variant="ghost" onPress={() => Alert.alert('End this cooking session?', 'Your recipe stays in your kitchen. This attempt will not earn XP or create a journal entry. Check any food on the heat before leaving.', [{ text: 'Keep cooking', style: 'cancel' }, { text: 'End session', style: 'destructive', onPress: () => { void act(async (repo) => { await repo.abandonSession(id); await reconcileTimers((await repo.snapshot()).timers); }).then(() => router.replace('/(tabs)')).catch(() => undefined); } }])}/>}
      {timers.length > 0 && <View style={{ gap: 12 }}><Text variant="heading">On the go</Text>{timers.map(timer => <View key={timer.id} style={[styles.timer, { backgroundColor: colors.surface }]}><Ionicons name="timer-outline" size={23} color={colors.primary}/><View style={{ flex: 1 }}><Text variant="label">{timer.label}</Text><Text color={timerRemaining(timer.endsAt, now) === 0 ? colors.accent : colors.primary}>{timerRemaining(timer.endsAt, now) === 0 ? 'Ready to check' : formatDuration(timerRemaining(timer.endsAt, now))}</Text></View><IconButton name="close" label={`Dismiss ${timer.label} timer`} onPress={() => mutate(repo => dismissTimer(repo, timer.id))}/></View>)}</View>}
    </ScrollView>
    <View style={[styles.footer, { borderTopColor: colors.border }]}>
      <Pressable accessibilityRole="button" onPress={() => router.push({ pathname: '/cook/timers', params: { sessionId: id } })} style={styles.footerAction}><Ionicons name="timer-outline" size={24} color={colors.primary}/><Text variant="caption" color={colors.primary}>Timers</Text></Pressable>
      <Pressable accessibilityRole="button" onPress={() => { void Speech.stop(); router.push({ pathname: '/(tabs)/chef', params: { recipeId: recipe.id, sessionId: id } }); }} style={styles.footerAction}><Ionicons name="sparkles-outline" size={24} color={colors.primary}/><Text variant="caption" color={colors.primary}>Ask Chef</Text></Pressable>
      {(session.status === 'cooking' || session.status === 'paused') && <Pressable accessibilityRole="button" disabled={busy} onPress={() => mutate(repo => session.status === 'paused' ? repo.resumeSession(id) : repo.pauseSession(id))} style={styles.footerAction}><Ionicons name={session.status === 'paused' ? 'play-outline' : 'pause-outline'} size={24} color={colors.primary}/><Text variant="caption" color={colors.primary}>{session.status === 'paused' ? 'Resume' : 'Pause'}</Text></Pressable>}
    </View>
  </SafeAreaView>;
}
function CheckRow({ label, checked, onPress }: {
    label: string;
    checked: boolean;
    onPress: () => void;
}) { const { colors } = useTheme(); return <Pressable accessibilityRole="checkbox" accessibilityState={{ checked }} onPress={onPress} style={{ minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 10 }}><Ionicons name={checked ? 'checkbox' : 'square-outline'} size={27} color={colors.primary}/><Text style={{ flex: 1, textDecorationLine: checked ? 'line-through' : 'none' }} color={checked ? colors.muted : colors.text}>{label}</Text></Pressable>; }
const styles = StyleSheet.create({ safe: { flex: 1 }, top: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 18 }, content: { padding: 24, paddingTop: 8, paddingBottom: 36, gap: 20 }, facts: { flexDirection: 'row', flexWrap: 'wrap', gap: 18 }, between: { flexDirection: 'row', alignItems: 'center', gap: 12, justifyContent: 'space-between' }, ingredientNote: { padding: 20, borderRadius: 14, gap: 10 }, timer: { borderRadius: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 }, footer: { flexDirection: 'row', borderTopWidth: 1, paddingTop: 10, paddingHorizontal: 20, gap: 12 }, footerAction: { flex: 1, minHeight: 56, alignItems: 'center', justifyContent: 'center', gap: 4 } });
