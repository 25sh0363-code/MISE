import '../global.css';
import React, { useEffect } from 'react';
import { AppState, View, ActivityIndicator, StyleSheet, Pressable, Text as NativeText } from 'react-native';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import * as Notifications from 'expo-notifications';
import { useMise } from '../src/state/app';
import { useTheme } from '../src/theme';
import { reconcileTimers } from '../src/services/timers';
import { useAutomaticSync } from '../src/services/auto-sync';
export { ErrorBoundary } from 'expo-router';
const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 60000 }, mutations: { retry: false } } });
function Navigation() {
    useAutomaticSync();
    const { colors, dark } = useTheme();
    const { ready, error, init, refresh, snapshot, toast, notify } = useMise();
    useEffect(() => { void init(); }, [init]);
    useEffect(() => {
        if (!ready)
            return;
        void reconcileTimers(snapshot?.timers ?? []);
        const subscription = AppState.addEventListener('change', state => { if (state === 'active')
            void refresh().catch(() => undefined); });
        const notifications = Notifications.addNotificationResponseReceivedListener(response => {
            const id = response.notification.request.content.data?.sessionId;
            if (typeof id === 'string')
                router.push({ pathname: '/cook/[id]', params: { id } });
        });
        void Notifications.getLastNotificationResponseAsync().then(response => {
            const id = response?.notification.request.content.data?.sessionId;
            if (typeof id === 'string')
                router.push({ pathname: '/cook/[id]', params: { id } });
        }).catch(() => undefined);
        return () => { subscription.remove(); notifications.remove(); };
    }, [ready]);
    useEffect(() => { if (!toast)
        return; const id = setTimeout(() => notify(null), 4500); return () => clearTimeout(id); }, [toast, notify]);
    if (!ready)
        return <View style={[styles.loading, { backgroundColor: colors.bg }]}><NativeText style={{ fontFamily: 'Georgia', fontSize: 46, color: colors.primary }}>mise.</NativeText>{error ? <><NativeText style={{ color: colors.text, margin: 24, textAlign: 'center' }}>Your local kitchen needs another try. {error}</NativeText><Pressable onPress={() => void init()} style={{ padding: 20 }}><NativeText style={{ color: colors.primary }}>Open my kitchen again</NativeText></Pressable></> : <ActivityIndicator color={colors.primary} style={{ marginTop: 24 }}/>}</View>;
    return <>
    <StatusBar style={dark ? 'light' : 'dark'}/>
    <Stack screenOptions={{ headerStyle: { backgroundColor: colors.bg }, headerTintColor: colors.text, headerShadowVisible: false, contentStyle: { backgroundColor: colors.bg }, headerBackButtonDisplayMode: 'minimal' }}>
      <Stack.Screen name="index" options={{ headerShown: false }}/>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }}/>
      <Stack.Screen name="onboarding" options={{ headerShown: false, gestureEnabled: false }}/>
      <Stack.Screen name="recipe/[id]" options={{ title: 'Recipe' }}/>
      <Stack.Screen name="recipe/edit" options={{ title: 'Your recipe', presentation: 'modal' }}/>
      <Stack.Screen name="cook/[id]" options={{ headerShown: false, presentation: 'fullScreenModal' }}/>
      <Stack.Screen name="cook/timers" options={{ title: 'Kitchen timers', presentation: 'formSheet', sheetAllowedDetents: [0.6, 1], sheetGrabberVisible: true }}/>
      <Stack.Screen name="session/[id]" options={{ title: 'A little reflection', presentation: 'modal', gestureEnabled: false }}/>
      <Stack.Screen name="journal" options={{ title: 'Cooking journal' }}/>
      <Stack.Screen name="settings" options={{ title: 'Your kitchen' }}/>
    </Stack>
    {!!toast && <Pressable accessibilityRole="alert" onPress={() => notify(null)} style={[styles.toast, { backgroundColor: colors.primary }]}><NativeText style={{ color: colors.onPrimary, fontSize: 15 }}>{toast}</NativeText></Pressable>}
  </>;
}
export default function RootLayout() { return <GestureHandlerRootView style={{ flex: 1 }}><SafeAreaProvider><QueryClientProvider client={queryClient}><Navigation /></QueryClientProvider></SafeAreaProvider></GestureHandlerRootView>; }
const styles = StyleSheet.create({ loading: { flex: 1, justifyContent: 'center', alignItems: 'center' }, toast: { position: 'absolute', left: 20, right: 20, bottom: 112, borderRadius: 14, padding: 18 } });
