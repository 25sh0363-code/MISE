import React, { useEffect, useRef, useState } from 'react';
import { View, Pressable, Image, Alert, BackHandler } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, useReducedMotion } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { Screen, Text, Button, Field, Divider } from '../../src/components/ui';
import { useMise } from '../../src/state/app';
import { useTheme } from '../../src/theme';
import { formatDuration, elapsedSeconds } from '../../src/domain/progression';
import type { Ratings, Review } from '../../src/domain/types';
import { pickCookingPhoto } from '../../src/services/photos';
import { reconcileTimers } from '../../src/services/timers';
const blankRatings: Ratings = { taste: 0, texture: 0, presentation: 0, overall: 0 };
export default function ReviewScreen() {
    const { id } = useLocalSearchParams<{
        id: string;
    }>();
    const { snapshot, act, busy, notify } = useMise();
    const { colors } = useTheme();
    const session = snapshot?.sessions.find(s => s.id === id);
    const existing = snapshot?.journal.find(entry => entry.sessionId === id);
    const [review, setReview] = useState<Review>(() => ({ ratings: session?.reviewDraft?.ratings ?? blankRatings, notes: session?.reviewDraft?.notes ?? '', improvements: session?.reviewDraft?.improvements ?? '', photos: session?.reviewDraft?.photos ?? [] }));
    const [savedXP, setSavedXP] = useState<number | null>(existing?.xp ?? null);
    const dirty = useRef(false);
    const reduced = useReducedMotion();
    const scale = useSharedValue(1);
    const badgeStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
    useEffect(() => { if (savedXP !== null && !reduced) {
        scale.value = 0.85;
        scale.value = withSpring(1, { damping: 11, stiffness: 180 });
    } }, [savedXP, reduced, scale]);
    useEffect(() => {
        if (!dirty.current || !session || session.status !== 'reviewing')
            return;
        const timer = setTimeout(() => { void act(repo => repo.updateSession(id, { reviewDraft: review })).catch(() => undefined); }, 500);
        return () => clearTimeout(timer);
    }, [review]);
    useEffect(() => { const subscription = BackHandler.addEventListener('hardwareBackPress', () => { router.replace('/(tabs)'); return true; }); return () => subscription.remove(); }, []);
    function change(next: Partial<Review>) { dirty.current = true; setReview(current => ({ ...current, ...next })); }
    async function photo(camera: boolean) { try {
        const uri = await pickCookingPhoto(camera);
        if (uri)
            change({ photos: [...review.photos, uri].slice(0, 8) });
    }
    catch (e) {
        Alert.alert('Photo access', e instanceof Error ? e.message : 'Could not save this photo. Try again.');
    } }
    function choosePhoto() { Alert.alert('Your finished dish', 'Add a photo to remember this cook.', [{ text: 'Take a photo', onPress: () => void photo(true) }, { text: 'Choose from library', onPress: () => void photo(false) }, { text: 'Cancel', style: 'cancel' }]); }
    async function save() {
        try {
            const entry = await act(repo => repo.completeSession(id, review));
            dirty.current = false;
            setSavedXP(entry.xp);
            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await reconcileTimers(useMise.getState().snapshot?.timers ?? []);
        }
        catch { /* The review remains available to retry. */ }
    }
    if (!session)
        return <Screen><Text variant="title">We couldn’t find this session.</Text><Button label="My cooking journal" onPress={() => router.replace('/journal')}/></Screen>;
    if (savedXP !== null)
        return <Screen><View style={{ alignItems: 'center', paddingTop: 34, gap: 22 }}><Animated.View style={[{ width: 100, height: 100, borderRadius: 50, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' }, badgeStyle]}><Ionicons name="ribbon-outline" size={56} color={colors.gold}/></Animated.View><Text variant="display" style={{ textAlign: 'center' }}>Made with a little{'\n'}more confidence.</Text><Text color={colors.muted} style={{ textAlign: 'center' }}>{session.recipe.name} is in your cooking journal.</Text><Text variant="title" color={colors.primary}>+{savedXP} practice XP</Text><Text color={colors.muted}>You showed up, cooked, and reflected. That’s how a chef grows.</Text></View><Divider /><Button label="See my culinary journey" icon="leaf-outline" onPress={() => router.replace('/(tabs)/journey')}/><Button label="View cooking journal" variant="secondary" onPress={() => router.replace('/journal')}/><Button label="Back to my kitchen" variant="ghost" onPress={() => router.replace('/(tabs)')}/></Screen>;
    if (session.status !== 'reviewing')
        return <Screen><Text variant="title">Your recipe is still cooking.</Text><Button label="Return to cooking" onPress={() => router.replace({ pathname: '/cook/[id]', params: { id } })}/></Screen>;
    const complete = Object.values(review.ratings).every(value => value >= 1 && value <= 5);
    return <Screen><Text variant="display">How did it taste?</Text><Text color={colors.muted}>A small reflection makes the next cook even better.</Text><View style={{ flexDirection: 'row', gap: 16, alignItems: 'center' }}><Ionicons name="time-outline" size={25} color={colors.primary}/><View><Text variant="label">{session.recipe.name}</Text><Text color={colors.muted}>Actual kitchen time · {formatDuration(elapsedSeconds(session))}</Text></View></View><Divider />
    {(['taste', 'texture', 'presentation', 'overall'] as const).map(key => <View key={key} style={{ gap: 8 }}><Text variant="label">{key.charAt(0).toUpperCase() + key.slice(1)}</Text><View accessibilityRole="radiogroup" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{[1, 2, 3, 4, 5].map(value => <Pressable key={value} accessibilityRole="radio" accessibilityState={{ selected: review.ratings[key] === value }} accessibilityLabel={`${key}: ${value} out of 5`} onPress={() => { change({ ratings: { ...review.ratings, [key]: value } }); void Haptics.selectionAsync(); }} style={{ width: 48, height: 48, justifyContent: 'center', alignItems: 'center' }}><Ionicons name={value <= review.ratings[key] ? 'star' : 'star-outline'} size={29} color={colors.gold}/></Pressable>)}</View></View>)}
    <Field label="What went well?" placeholder="The bun was golden, the sauce was just right…" multiline value={review.notes} onChangeText={notes => change({ notes })} maxLength={4000} style={{ minHeight: 100 }}/><Field label="For next time" placeholder="One little thing I’d try differently…" multiline value={review.improvements} onChangeText={improvements => change({ improvements })} maxLength={4000} style={{ minHeight: 90 }}/>
    <View style={{ flexDirection: 'row', gap: 12, flexWrap: 'wrap' }}>{review.photos.map((uri, index) => <Pressable key={uri} onPress={() => Alert.alert('Remove this photo?', 'It will be removed from this entry.', [{ text: 'Keep', style: 'cancel' }, { text: 'Remove', style: 'destructive', onPress: () => change({ photos: review.photos.filter((_, i) => i !== index) }) }])} accessibilityLabel="Remove cooking photo" accessibilityRole="button"><Image source={{ uri }} style={{ width: 94, height: 94, borderRadius: 12 }}/></Pressable>)}</View>
    <Button label="Add a photo" icon="camera-outline" variant="secondary" onPress={choosePhoto} disabled={review.photos.length >= 8}/><Text variant="caption" color={colors.muted}>Your photos and reflection are saved on this device. Cloud sync is available in Kitchen settings.</Text><Button label={complete ? 'Save my cook & earn XP' : 'Rate all four qualities to save'} disabled={!complete || busy} loading={busy} onPress={() => void save()}/><Button label="Reflect later · cooking time is saved" variant="ghost" onPress={() => { void act(repo => repo.updateSession(id, { reviewDraft: review })).then(() => { notify('Your reflection is waiting in Continue cooking.'); router.replace('/(tabs)'); }).catch(() => undefined); }}/>
  </Screen>;
}
