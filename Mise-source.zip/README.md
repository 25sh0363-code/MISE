# Mise · your culinary adventure

Native iOS and Android app built with Expo SDK 54 and TypeScript. There is no website, desktop UI or PWA target.

## Run

Use Node 22.18 or newer, an iPhone/Android device with a compatible development build, or Xcode/Android Studio with a simulator/emulator.

```sh
npm install
npx expo install --fix
npm run doctor
npm run ios
# or
npm run android
```

`npm start` starts Metro for an installed native development client. `npx eas-cli build --profile preview --platform android` creates an APK after configuring an Expo account. Production iOS builds require Apple signing. EAS profiles are in `eas.json`; no build has been submitted.

This workspace could not reach the npm registry (DNS blocked), so dependencies are declared but installation, a lockfile, Metro bundling and a full dependency-aware TypeScript check could not be completed. Run the commands above in a network-enabled environment before treating this as a validated native build. SDK 54 is an explicit compatibility baseline; use its development client rather than assuming the current Expo Go release supports it.

A standalone APK cloud workflow is ready in `.github/workflows/android-apk.yml`. It builds on a temporary GitHub runner and leaves no Android SDK on this Mac. See [APK build details](docs/apk-build.md). The workflow has not been run yet.

## Local kitchen mode

No environment variables are needed for the local cooking journey. First launch opens onboarding. Discover includes the complete Burger Workshop and recipes beyond burgers. Save a recipe, check ingredients and equipment, cook one step at a time, set timers, finish and rate the dish, save a journal entry, and view real XP in Journey. Create and edit your own recipes across cuisines, add photographs and collections, favorite, archive, duplicate, and search.

SQLite owns local recipes, immutable session recipe snapshots, checklists, timer deadlines, review drafts, journal entries, preferences, queued mutations and photo upload mappings. Recipe changes cannot change a meal already in progress. Journal creation, session completion, XP and queued synchronization commit in one transaction; retrying completion cannot award duplicate XP. User progress starts empty.

Multiple timers use absolute timestamps and local notifications when permitted. JavaScript intervals only refresh the on-screen clock. App reopen reconstructs remaining time from SQLite and reconciles scheduled notifications. Pausing a cooking session pauses its recorded duration, while food timers continue. Finishing freezes the actual kitchen time before the review. Notifications depend on OS permissions and device settings.

Photos chosen from the library or camera are copied to app documents before being attached to a recipe or journal entry. A photo is never removed just because an upload fails. Native text-to-speech reads a step while the app is active. System keyboard dictation provides optional question input where enabled; there is no continuous listening.

## Cloud and AI

Copy `.env.example` to `.env` and set only the Supabase public URL and anonymous/publishable client key. Deploy the migration and Edge Function using [backend instructions](docs/backend.md). Sign in from Kitchen settings. Sync runs after local changes, on foreground/connectivity events and periodically while foregrounded; a manual sync action is also available.

The provider key belongs only in Supabase server secrets. Chef supports provider adapters and validates structured responses before returning them. The app displays AI suggestions and requires confirmation before saving a draft. There are no canned AI replies. Without cloud configuration Chef clearly explains local mode, while recipes and cooking remain usable.

Sync uses an immutable outbox, expected revisions, server mutation receipts, tombstones, private Storage and owner-bound local data. Conflicting records keep both payloads for explicit review. A different signed-in account cannot silently take ownership of a previously bound local kitchen.

## Verification

```sh
npm test
npm run verify:source
npm run typecheck
npm run bundle:ios
npm run bundle:android
```

The repository tests run against actual SQLite through Node's built-in driver, not a mocked database. They exercise file reopen, background timer deadlines, paused elapsed time, transactional rollback, immutable recipe snapshots, idempotent completion/XP, queue revision handling and account isolation. Source verification checks syntax, local imports and bundled files; it is not a replacement for a native build.

Native device testing, accessibility visual review and live Supabase/provider integration are still required. See [native QA](docs/native-qa.md), [design decisions](DESIGN.md), [backend deployment](docs/backend.md), and [artwork provenance](docs/assets.md).
