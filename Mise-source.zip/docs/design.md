# Native surfaces

Mode: Operate. The application succeeds when a cook can find the next action with occupied hands and intermittent connectivity.

The visual anchor is the personal recipe book: warm ground, generous reading rhythm, recipe photography and calm forest controls. Native navigation and controls stay familiar. One animated signature is the earned progress fill; system reduced motion disables its animation.

The Kitchen features a greeting and a full-width food photograph. Discover broadens beyond starter content through cuisine, ingredient, difficulty and time searches. Cookbook persists saved recipes and authored collections. Recipe details keep quantities, servings, equipment and instructions readable. Journey contains only derived practice evidence. Chef uses server-side structured recipe drafts with an explicit save confirmation.

Light and dark palettes, scale-friendly text, 48-point targets, accessible icon labels, zero-history empty states, and visible cloud status are part of the shared components. Confirm on actual iOS and Android devices before release.
