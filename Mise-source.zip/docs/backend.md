# MISE cloud and AI deployment

The native app works in local kitchen mode with both public environment values blank. SQLite is authoritative for recipes, cooking sessions, timers, preferences, journal entries and earned progress. No account or AI service is simulated.

## Connect a Supabase project

1. Create a Supabase project, copy `.env.example` to `.env`, and set the project URL and **publishable/anon** key. Never put a service-role key or AI key in an `EXPO_PUBLIC_` variable.
2. From this folder run `supabase link --project-ref YOUR_PROJECT_REF`, then `supabase db push`. The migration creates all product tables, private ownership policies, a private 10 MB photo bucket, mutation receipts and the AI quota function.
3. Enable email/password authentication in Supabase. The app uses encrypted, chunked Expo SecureStore for sessions. Email confirmation remains controlled by the project Auth settings.
4. Set server secrets with the Supabase dashboard or `supabase secrets set`. Required: `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`. Optional: `AI_ADAPTER` (`openai-compatible`, the default, or `anthropic`). The base URL includes the provider's API version, such as `https://provider.example/v1`; the adapter appends `/chat/completions` or `/messages`.
5. Deploy using `supabase functions deploy chef`. The function verifies the signed-in user, and the Supabase gateway JWT check is also enabled. No service-role credential is needed by the function.
6. Restart Metro after setting public environment values. Sign in from Settings, then choose Sync now. The app also retries eligible sync on foreground/connectivity events where enabled by the app shell.

The OpenAI-compatible adapter requires JSON Schema structured-output support. The Anthropic adapter uses a forced tool call with the same schema. Add another adapter in `supabase/functions/chef/provider.ts` without changing mobile credentials or the client response model. Provider errors are never replaced by fabricated cooking advice.

## Synchronization guarantees

- Each local mutation receives a durable, immutable ID and the last acknowledged cloud revision. Direct client writes to sync-managed tables and recipe versions are denied; the server uses an atomic compare-and-swap RPC, an advisory transaction lock, and a receipt keyed by user and mutation ID. A retry after a lost acknowledgement replays the receipt.
- Acknowledgement removes only the accepted mutation and advances queued revisions atomically. The client re-fetches the queue head for every send. Interrupted calls leave pending changes intact.
- Conflict responses preserve the local queue and the remote payload. Settings exposes an explicit choice. Both versions are retained in the local conflict archive after resolution. There is no silent last-write-wins rule.
- Cloud deletions are revisioned tombstones; another device cannot resurrect them with a stale revision. Cooking history is retained locally. Abandoning a session records the abandoned state and awards no XP.
- A full paginated pull merges only entities with no pending or conflicted local mutations. It pulls sessions before their journal entries. The next run can safely retry a partial pull.
- A local library is bound to the first account used for sync. Sync refuses a different account, protecting one person's local records from upload into another account. Signing out does not erase the local library. Separate accounts require a separate installation or a deliberate data migration; automatic account switching is not offered.
- Photographs are copied into the app's permanent documents directory before journaling or recipe saving. The upload queue retains local files after upload. Uploaded mappings replace device paths with private `storage://` references in cloud payloads. On another device, signed URLs download photos to permanent local files before records are merged. Files are committed from a temporary path only after successful download.
- Timers remain device-local. Their timestamps and native scheduled notifications survive process interruption; another device does not unexpectedly receive timer alarms.

## AI context and safety

Chef reads only the authenticated user's cloud records. The mobile request may also include explicitly marked, unsynchronized local preferences, saved-recipe summaries, recent practice, the current recipe and session. Stored or supplied data is treated as user context, never instructions or independently verified history. The API response is validated on the server and mobile client. Recipe changes are drafts and require the visible user confirmation before persistence.

Requests are limited to 32 KB, 4,000 question characters, six requests per minute and 30 per day per user. Provider calls time out after 45 seconds. The function stores actual user and assistant messages only after a validated answer. It never records fake assistant responses or invented completed cooking sessions. Quota counts include failed provider attempts to bound abuse and costs.

Food-safety facts used in the system prompt come from [FoodSafety.gov's minimum temperature chart](https://www.foodsafety.gov/food-safety-charts/safe-minimum-internal-temperatures) and [USDA guidance](https://ask.fsis.usda.gov/article/What-is-a-safe-internal-temperature-for-cooking-meat-and-poultry): ground beef/pork/lamb reaches 160°F / 71°C; all poultry reaches 165°F / 74°C, checked with a food thermometer. Generated culinary suggestions are labeled as AI suggestions, not verified recipes or allergy certifications.

## Verification and remaining environment steps

The migration, storage rules, Edge Function and client code are implemented. They have **not** been deployed or exercised against a live Supabase project in this workspace: no project credentials were supplied. Apply the migration to a disposable project and run `supabase/tests/security.sql` using the SQL editor or a PostgreSQL connection before production. That transactional script checks user isolation, idempotent mutation retries, conflict detection, version preservation and the null-revision guard, direct-write denial and read-only recipe versions, then rolls back its fixtures.

Run the provider against real structured-output responses, verify email confirmation and expired sessions, test photo upload/retrieval and cross-device conflict choices, and verify both iOS and Android foreground/offline behavior before a store release. Client install and device testing are documented in the root README.
