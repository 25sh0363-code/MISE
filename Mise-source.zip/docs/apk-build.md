# Standalone Android APK

`.github/workflows/android-apk.yml` builds an installable native APK on a temporary GitHub Linux runner. No Expo account, AI credential or Supabase credential is required for this local-mode build. It does not install an SDK on the user's Mac.

The workflow installs compatible dependencies, runs application type checking and tests, generates native Android sources, builds a release APK containing its JavaScript bundle, verifies the native libraries and signature, then uploads `Mise.apk` as the `Mise-Android-APK` artifact. It also keeps the resolved dependency lockfile for reproducibility. This is a sideload/testing build using the generated Android project's development signing configuration; store distribution needs a managed private signing key.

It runs on a push to `main` or from Actions → Build Mise APK → Run workflow. Build errors must be fixed from the real job logs before an APK can be delivered. This workflow has been prepared but has not yet been run: the current workspace cannot reach npm or Expo, has no Android SDK, and has no connected GitHub account.

GitHub-hosted runners are temporary. Application source remains in its repository and the APK remains as a downloadable artifact; build SDKs and dependencies stay on the disposable runner. Artifact retention is 14 days. A private repository keeps source access limited to its collaborators; account-specific Actions limits may apply.

To build in an already configured Android environment, install the project dependencies, run `npx expo install --fix`, then run `bash scripts/build-apk.sh`. The result is `dist/Mise.apk`. The script never deletes existing SDKs or project dependencies. Required runtime libraries are packaged in the APK and do not need to be installed on the phone separately.
