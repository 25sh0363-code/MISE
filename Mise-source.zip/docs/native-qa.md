# Native release verification

No simulator, Android SDK or connected mobile device was available in the authoring environment. This is a required execution checklist, not a claim of passing device tests.

Run on iPhone and Android phone development builds:

1. Fresh install: complete all onboarding preferences; revisit settings and confirm persistence.
2. Discover cheeseburger, save it, verify Cookbook, then force-close and reopen.
3. Open recipe, create a servings variation, review ingredient quantities and written instructions in the editor, and save. Start preparation; verify quantities and checklists survive reopening.
4. Start cooking, move through steps, speak an instruction, pause/resume, navigate to Chef and return.
5. Start two timers. Background the app, close/reopen it, and verify remaining time against wall-clock time. Test permitted and denied notifications; never infer doneness from timer completion.
6. Finish cooking, wait on review screen and confirm actual kitchen time stays frozen. Rate four qualities, add camera/library photos, notes and improvement. Close/reopen before saving; draft should remain.
7. Save review twice rapidly; exactly one journal entry and one XP award must appear. Restart and verify history, skills and achievement.
8. Make and cook a non-burger manual recipe, edit the saved recipe during a session, and confirm the active session retains its snapshot.
9. Check all five tabs in light/dark, largest practical text size, screen reader, reduced motion, small phone, Android system Back, iOS edge-swipe and keyboard open.
10. Configure a staging Supabase project. Test sign-up/email verification/sign-in, background/foreground sync, airplane mode, interrupted uploads, two-device conflicts, explicit conflict resolution, expired auth, and account ownership guard.
11. Run authenticated AI draft generation, ingredient discovery, substitution, technique advice and live-session help. Confirm unknown preferences stay unknown and saving always asks confirmation. Verify another user's data is unreadable through RLS/Storage.
12. Run SQL smoke tests in a disposable local Supabase database, TypeScript check, Expo Doctor, both native bundles, preview APK and signed iOS build before distribution.

## Automated evidence

`npm test` uses real Node SQLite and temporary database files. `npm run verify:source` checks source syntax, local imports and asset existence. These checks do not verify gestures, native module linkage, visual layout, notification delivery or real provider responses.
