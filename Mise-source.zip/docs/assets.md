# Bundled artwork

Created with the built-in imagegen tool for this project. Both images are decorative recipe imagery, not photographs of user cooking. They never enter journal entries automatically.

- `assets/images/burger.png`: 1536 × 1024 food photograph, used for burger starter recipes.
- `assets/images/pasta.png`: 1254 × 1254 food photograph, used for the tomato pasta starter recipe.

The typographic native app icons (`icon.png`, `adaptive-icon.png`) are rendered by `scripts/create-icon.py`; they are original UI graphics rather than generated photographs. The font is rasterized at build-authoring time and is not bundled.

Final prompts:

> Use case: photorealistic-natural. Asset type: bundled recipe cover photograph for MISE, a warm premium native cooking app. Create a beautiful close-up editorial food photograph of one classic homemade cheeseburger with melted cheddar, lettuce, tomato and pickles in a toasted sesame brioche bun, with a small portion of golden thin crispy French fries on a cream ceramic plate on a warm ivory linen table. Natural afternoon window light, warm forest-green napkin in the background, subtle real texture, delicious honest food, 50mm lens shallow depth. Landscape composition, burger prominent centered, all food visible, no hands, no words, no graphic overlays, no logos, no watermark. High quality culinary magazine photography.

> Use case: photorealistic-natural. Asset type: bundled recipe photograph for premium warm cooking app Mise. A rustic cream ceramic shallow bowl holding glossy spaghetti al pomodoro with ripe red tomato sauce, three fresh basil leaves and grated parmesan on ivory linen, soft natural afternoon side light, forest green cotton napkin blurred in background, close editorial food photography, handmade inviting food, tasteful magazine art direction, square composition centered complete bowl, no text, no logos, no people, no watermark.
