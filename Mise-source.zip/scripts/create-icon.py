"""Render the typographic app mark; no runtime dependency or bundled font."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root = Path(__file__).resolve().parents[1] / 'assets' / 'images'
font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Georgia Italic.ttf', 650)
mark = Image.new('RGBA', (1024, 1024), (0, 0, 0, 0))
draw = ImageDraw.Draw(mark)
box = draw.textbbox((0, 0), 'm', font=font)
x = (1024 - (box[2] - box[0])) / 2 - box[0] - 15
y = (1024 - (box[3] - box[1])) / 2 - box[1] - 15
draw.text((x, y), 'm', font=font, fill='#F8F5EF')
mark.save(root / 'adaptive-icon.png')
icon = Image.new('RGBA', (1024, 1024), '#344E41')
icon.alpha_composite(mark)
icon.convert('RGB').save(root / 'icon.png')
