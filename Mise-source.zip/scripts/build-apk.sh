#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo 'An Android SDK is required. The GitHub APK workflow supplies it on its temporary runner.' >&2
  exit 1
fi
export CI=1
export EXPO_NO_TELEMETRY=1
npx expo prebuild --platform android --no-install
(
  cd android
  chmod +x gradlew
  ./gradlew :app:assembleRelease --no-daemon --max-workers=2
)
mkdir -p dist
cp android/app/build/outputs/apk/release/app-release.apk dist/Mise.apk
# Verify this is a signed, native, standalone installation package.
python3 - <<'PY'
from zipfile import ZipFile
from pathlib import Path
apk = Path('dist/Mise.apk')
with ZipFile(apk) as archive:
    files = archive.namelist()
    assert 'AndroidManifest.xml' in files, 'Missing Android manifest'
    assert 'assets/index.android.bundle' in files, 'Missing standalone JavaScript bundle'
    assert any(p.startswith('lib/') and p.endswith('.so') for p in files), 'Missing native libraries'
print(f'Standalone native APK: {apk.resolve()} ({apk.stat().st_size:,} bytes)')
PY
sdk_root="${ANDROID_HOME:-$ANDROID_SDK_ROOT}"
apksigner_path="$(find "$sdk_root/build-tools" -name apksigner -type f | sort | tail -n 1)"
if [[ -z "$apksigner_path" ]]; then
  echo 'The Android signing verifier was not installed.' >&2
  exit 1
fi
"$apksigner_path" verify --verbose dist/Mise.apk
