const fs = require('fs');
const path = require('path');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const files = [];
for (const folder of ['app','src','supabase/functions']) walk(path.join(root, folder));
function walk(dir) { for (const entry of fs.readdirSync(dir, {withFileTypes:true})) { const file = path.join(dir,entry.name); if(entry.isDirectory())walk(file); else if(/\.tsx?$/.test(entry.name) && !/\.d\.ts$/.test(entry.name))files.push(file); } }
let errors = 0;
for(const file of files) {
  const source = fs.readFileSync(file,'utf8');
  const result = ts.transpileModule(source,{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,isolatedModules:true}});
  for(const diagnostic of result.diagnostics ?? []) { if(diagnostic.category===ts.DiagnosticCategory.Error){ console.error(path.relative(root,file),ts.flattenDiagnosticMessageText(diagnostic.messageText,' '));errors++;} }
  const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true);
  function visit(node) {
    let specifier;
    if(ts.isImportDeclaration(node)||ts.isExportDeclaration(node))specifier=node.moduleSpecifier?.text;
    if(ts.isCallExpression(node)&&node.expression.getText(ast)==='require'&&node.arguments.length===1&&ts.isStringLiteral(node.arguments[0]))specifier=node.arguments[0].text;
    if(specifier?.startsWith('.')) {
      const target=path.resolve(path.dirname(file),specifier);
      if(![target,`${target}.ts`,`${target}.tsx`,`${target}.js`,path.join(target,'index.ts'),path.join(target,'index.tsx')].some(p=>fs.existsSync(p)&&fs.statSync(p).isFile())){console.error(`${path.relative(root,file)}: missing ${specifier}`);errors++;}
    }
    ts.forEachChild(node,visit);
  }
  visit(ast);
}
if(errors)process.exitCode=1;
else console.log(`Checked syntax, relative imports and bundled assets in ${files.length} TypeScript files. This does not replace a dependency-aware typecheck or native build.`);
