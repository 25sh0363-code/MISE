module.exports = {
  content: ['./app/**/*.{ts,tsx}', './src/**/*.{ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: { extend: { colors: { ivory:'#F8F5EF',cream:'#EFE8DA',forest:'#344E41',sage:'#A3B18A',terracotta:'#C87956',espresso:'#29251F',gold:'#D4A65A' } } },
  plugins: [],
};
